<?php 
require_once("includes/db_connection.php");
require_once("includes/functions.php"); ?>
<?php include("includes/profile.php");?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="includes/kickstart/js/kickstart.js"></script> <!-- KICKSTART -->
	<div id="content">
<html lang="en">
	<head>
	<meta charset="utf8">	
		<link rel="stylesheet" href="includes/kickstart/css/kickstart.css" media="all" />
	</head>
	<body>
<?php
//Proverava da li je prosledjen ID
if (empty($_GET["id"])){
	$id = "";
}
else{
//Izvršava upit i deljuje vrednosti prom.
	$id = test_input($_GET["id"]);}
	$error = 0;
	$imeErr = $prezimeErr = $roditeljErr = $datum_rodjenjaErr = $mesto_rodjenjaErr = $jmbg_pasosErr = $zanimanjeErr = $kompanijaErr = $drzavljanstvoErr = $emailErr = $fiksniErr = $mobilniErr = $maternji_jezikErr = $engleskiErr = $nemackiErr = $francuskiErr = $ostalo_jezikErr = $wordErr = $excelErr = $internetErr = $ostalo_racunariErr = $prethodno_volontiranjeErr = $vreme_volontiranjeErr = $ostalo_volontiranjeErr = $konfekcijski_brojErr = $ulicaErr = $gradErr = $postanski_brojErr = $drzavaErr = $trenutna_adresaErr = $ocenaErr = $sektorErr = $zapazanjaErr = "";
	$sql = "SELECT * FROM volonteri WHERE id='$id'";
	$result = $connection->query($sql);
	$row = $result->fetch_assoc();
	if (empty($row["ime"])){$ime="";}else{
	$ime = $row["ime"];}
	if (empty($row["prezime"])){$prezime="";}else{
	$prezime = $row["prezime"];}
	if (empty($row["email"])){$email="";}else{
	$email = $row["email"];}
	if (empty($row["roditelj"])){$roditelj="";}else{
	$roditelj = $row["roditelj"];}
	if (empty($row["datum_rodjenja"])){$datum_rodjenja="";}else{
	$datum_rodjenja = $row["datum_rodjenja"];}
	if (empty($row["mesto_rodjenja"])){$mesto_rodjenja="";}else{
	$mesto_rodjenja = $row["mesto_rodjenja"];}
	if (empty($row["jmbg_pasos"])){$jmbg_pasos="";}else{
	$jmbg_pasos = $row["jmbg_pasos"];}
	if (empty($row["zanimanje"])){$zanimanje="";}else{
	$zanimanje = $row["zanimanje"];}
	if (empty($row["kompanija"])){$kompanija="";}else{
	$kompanija = $row["kompanija"];}
	if (empty($row["drzavljanstvo"])){$drzavljanstvo="";}else{
	$drzavljanstvo = $row["drzavljanstvo"];}
	if (empty($row["ulica_broj"])){$ulica_broj="";}else{
	$ulica_broj = $row["ulica_broj"];}
	if (empty($row["grad"])){$grad="";}else{
	$grad = $row["grad"];}
	if (empty($row["postanski_broj"])){$postanski_broj="";}else{
	$postanski_broj = $row["postanski_broj"];}
	if (empty($row["drzava"])){$drzava="";}else{
	$drzava = $row["drzava"];}
	if (empty($row["adresa"])){$adresa="";}else{
	$adresa = $row["adresa"];}
	if (empty($row["email"])){$email="";}else{
	$email = $row["email"];}
	if (empty($row["fiksni"])){$fiksni="";}else{
	$fiksni = $row["fiksni"];}
	if (empty($row["mobilni"])){$mobilni="";}else{
	$mobilni = $row["mobilni"];}
	if (empty($row["maternji_jezik"])){$maternji_jezik="";}else{
	$maternji_jezik = $row["maternji_jezik"];}
	if (empty($row["engleski"])){$engleski="";}else{
	$engleski = $row["engleski"];}
	if (empty($row["francuski"])){$francuski="";}else{
	$francuski = $row["francuski"];}
	if (empty($row["nemacki"])){$nemacki="";}else{
	$nemacki = $row["nemacki"];}
	if (empty($row["ostalo_jezik"])){$ostalo_jezik="";}else{
	$ostalo_jezik = $row["ostalo_jezik"];}
	if (empty($row["word"])){$word="";}else{
	$word = $row["word"];}
	if (empty($row["excel"])){$excel="";}else{
	$excel = $row["excel"];}
	if (empty($row["internet"])){$internet="";}else{
	$internet = $row["internet"];}
	if (empty($row["ostalo_racunari"])){$ostalo_racunari="";}else{
	$ostalo_racunari = $row["ostalo_racunari"];}
	if (empty($row["prethodno_volontiranje"])){$prethodno_volontiranje="";}else{
	$prethodno_volontiranje = $row["prethodno_volontiranje"];}
	if (empty($row["ostalo_volontiranje"])){$ostalo_volontiranje="";}else{
	$ostalo_volontiranje = $row["ostalo_volontiranje"];}
	if (empty($row["vreme_volontiranje"])){$vreme_volontiranje="";}else{
	$vreme_volontiranje = $row["vreme_volontiranje"];}
	if (empty($row["konfekcijski_broj"])){$konfekcijski_broj="";}else{
	$konfekcijski_broj = $row["konfekcijski_broj"];}
	if (empty($row["ocena"])){$ocena="";}else{
	$ocena = $row["ocena"];}
	if (empty($row["sektor"])){$sektor="";}else{
	$sektor = $row["sektor"];}
	if (empty($row["zapazanja"])){$zapazanja="";}else{
	$zapazanja = $row["zapazanja"];}
																				


//hvatanje promenjivih iz forme i kontrola
	if ($_SERVER["REQUEST_METHOD"] == "POST"){
		$error = 0;
		
		//ID
		if (empty($_POST["id"])){
		$id = "";
		}
		else{
		$id = test_input($_POST["id"]);
		}
		//ime
		if (empty($_POST["ime"])){
			$imeErr = "Obavezno polje";
			$error = 1;}
		else{
		$ime = test_input($_POST["ime"]);}
		
		//prezime
		if (empty($_POST["prezime"])){
			$prezimeErr = "Obavezno polje";
			$error = 1;}
		else{
		$prezime = test_input($_POST["prezime"]);}
		
		//roditelj
		if (empty($_POST["roditelj"])){
			$roditelj = "";}
		else{
		$roditelj = test_input($_POST["roditelj"]);}
		
		//datum rođenja
		if (empty($_POST["datum_rodjenja"])){
			$datum_rodjenjaErr = "Obavezno polje";
			$error = 1;}
		else{
		$datum_rodjenja = test_input($_POST["datum_rodjenja"]);}
			
		
		//mesto rođenja
		if (empty($_POST["mesto_rodjenja"])){
			$mesto_rodjenja = "";}
		else{
		$mesto_rodjenja = test_input($_POST["mesto_rodjenja"]);}			
		
			
		//jmbg_pasos - provera da li su samo brojevi
		if (empty($_POST["jmbg_pasos"])){
			$jmbg_pasos = "";}	
		else {if (!is_numeric($_POST["jmbg_pasos"])){
			$jmbg_pasosErr = "Nepravilan unos";
			$error = 1;}}
		
		if	((!empty($_POST["jmbg_pasos"])) AND (is_numeric($_POST["jmbg_pasos"]))){
		$jmbg_pasos = test_input($_POST["jmbg_pasos"]);
		}
		
		//zanimanje
		if (empty($_POST["zanimanje"])){
			$zanimanje = "";}
		else{
		$zanimanje = test_input($_POST["zanimanje"]);}
		
		//kompanija
		if (empty($_POST["kompanija"])){
			$kompanija = "";}
		else{
		$kompanija = test_input($_POST["kompanija"]);}
		
		//državljanstvo
		if (empty($_POST["drzavljanstvo"])){
			$drzavljanstvoErr = "Obavezno polje";
			$error = 1;}
		else{
		$drzavljanstvo = test_input($_POST["drzavljanstvo"]);}
		
		//ulica i broj
		if (empty($_POST["ulica_broj"])){
			$ulica_broj = "";}
		else{
		$ulica_broj = test_input($_POST["ulica_broj"]);}
		
		//grad
		if (empty($_POST["grad"])){
			$grad = "";}
		else{
		$grad = test_input($_POST["grad"]);}
		
		//poštanski broj - brovera da li su samo brojevi
		if (empty($_POST["postanski_broj"])){
			$postanski_broj = "";}	
		else {if (!is_numeric($_POST["postanski_broj"])){
			$postanski_brojErr = "Nepravilan unos";
			$error = 1;}}
		
		if	((!empty($_POST["postanski_broj"])) AND (is_numeric($_POST["postanski_broj"]))){
		$postanski_broj = test_input($_POST["postanski_broj"]);
		}
		
		//mesto prebivališta
				
		//država
		if (empty($_POST["drzava"])){
			$drzava = "";}
		else{
		$drzava = test_input($_POST["drzava"]);}
		
		//trenutna adresa
		if (empty($_POST["adresa"])){
			$adresa = "";}
		else{
		$adresa = test_input($_POST["adresa"]);}

		//e-mail - Proverava pravilan unos e-maila
		if (empty($_POST["email"])){
		$emailErr = "Obavezno polje";
		$error = 1;}
		else{	
		if ((!filter_var(test_input($_POST["email"]), FILTER_VALIDATE_EMAIL))){
		$emailErr = "Nepravilan unos";
		$error = 1;
		}}
		if (((!empty($_POST["email"]))) AND (filter_var(test_input($_POST["email"]), FILTER_VALIDATE_EMAIL))){
		$email = test_input($_POST["email"]);}
		
		//fiksni
		if (empty($_POST["fiksni"])){
			$fiksni = "";}
		else{
		$fiksni = test_input($_POST["fiksni"]);}
		
		//mobilni
		if (empty($_POST["mobilni"])){
			$mobilniErr = "Obavezno polje";
			$error = 1;}
		else{
		$mobilni = test_input($_POST["mobilni"]);}
		
		//maternji jezik
		if (empty($_POST["maternji_jezik"])){
			$maternji_jezik = "";}
		else{
		$maternji_jezik = test_input($_POST["maternji_jezik"]);}
		
		//engleski
		if (empty($_POST["engleski"])){
			$engleskiErr = "Obavezno polje";
			$error = 1;}
		else{
		$engleski = test_input($_POST["engleski"]);}
		

		//francuski
		if (empty($_POST["francuski"])){
			$francuskiErr = "Obavezno polje";
			$error = 1;}
		else{
		$francuski = test_input($_POST["francuski"]);}
		
		//nemacki
		if (empty($_POST["nemacki"])){
			$nemackiErr = "Obavezno polje";
			$error = 1;}
		else{
		$nemacki = test_input($_POST["nemacki"]);}
		
		//ostali jezici
		if (empty($_POST["ostalo_jezik"])){
			$ostalo_jezik = "";}
		else{
		$ostalo_jezik = test_input($_POST["ostalo_jezik"]);}
		
		//word
		if (empty($_POST["word"])){
			$word = "";}
		else{
		$word = test_input($_POST["word"]);}
		
		//excel
		if (empty($_POST["excel"])){
			$excel = "";}
		else{
		$excel = test_input($_POST["excel"]);}
		
		//internet
		if (empty($_POST["internet"])){
			$internet = "";}
		else{
		$internet = test_input($_POST["internet"]);}
		
		//ostalo računari
		if (empty($_POST["ostalo_racunari"])){
			$ostalo_racunari = "";}
		else{
		$ostalo_racunari = test_input($_POST["ostalo_racunari"]);}
		
		//prethodno volontiranje
		if (empty($_POST["prethodno_volontiranje"])){
			$prethodno_volontiranjeErr = "Obavezno polje";
			$error = 1;}
		else{
		$prethodno_volontiranje = test_input($_POST["prethodno_volontiranje"]);}
		
		//ostalo volontiranje
		if ((empty($_POST["ostalo_volontiranje"])) AND ($prethodno_volontiranje == "Da")){
			$ostalo_volontiranjeErr = "Obavezno polje";
			$error = 1;}
		else{
		$ostalo_volontiranje = test_input($_POST["ostalo_volontiranje"]);}
		
		//vreme volontiranje
		if (empty($_POST["vreme_volontiranje"])){
			$vreme_volontiranjeErr = "Obavezno polje";
			$error = 1;}
		else{
		$vreme_volontiranje = test_input($_POST["vreme_volontiranje"]);}
		
		
		//konfekcijski broj
		if (empty($_POST["konfekcijski_broj"])){
			$konfekcijski_brojErr = "Obavezno polje";
			$error = 1;}
		else{
		$konfekcijski_broj = test_input($_POST["konfekcijski_broj"]);}
		
		//ocena
		if (empty($_POST["ocena"])){
			$ocena = "";}
		else{
		$ocena = test_input($_POST["ocena"]);}
		
		//sektor
		if (empty($_POST["sektor"])){
			$sektor = "";}
		else{
		$sektor = test_input($_POST["sektor"]);}
		
		//zapazanja
		if (empty($_POST["zapazanja"])){
			$zapazanja = "";}
		else{
		$zapazanja = test_input($_POST["zapazanja"]);}

if($error == 0){
$sql = "UPDATE volonteri SET id='$id', ime='$ime', prezime='$prezime', roditelj='$roditelj', datum_rodjenja='$datum_rodjenja', mesto_rodjenja='$mesto_rodjenja', jmbg_pasos='$jmbg_pasos', zanimanje='$zanimanje', kompanija='$kompanija', drzavljanstvo='$drzavljanstvo', ulica_broj='$ulica_broj', grad='$grad', postanski_broj='$postanski_broj', drzava='$drzava', adresa='$adresa', email='$email', fiksni='$fiksni', mobilni='$mobilni', maternji_jezik='$maternji_jezik', engleski='$engleski', francuski='$francuski', nemacki='$nemacki', ostalo_jezik='$ostalo_jezik', word='$word', excel='$excel', internet='$internet', ostalo_racunari='$ostalo_racunari', prethodno_volontiranje='$prethodno_volontiranje', ostalo_volontiranje='$ostalo_volontiranje', vreme_volontiranje='$vreme_volontiranje', konfekcijski_broj='$konfekcijski_broj', ocena='$ocena', sektor='$sektor', zapazanja='$zapazanja' WHERE id = '$id'";
	if(mysqli_query($connection, $sql)){
    echo "<div class='notice success'><i class='icon-ok icon-large'></i> Uspešno Ažurirano.<a href='#close' class='icon-remove'></a></div><br><br>";
	} 
else{
 echo "<div class='notice error'><i class='icon-remove-sign icon-large'></i> Došlo je do greške <a href='#close' class='icon-remove'></a></div>";
}}}

?>
	

<ul class="menu" id="printhide">
<li><form action="pretraga.php"><input type="submit" value="Pretraga">&nbsp</form></a></li>
<li><form action="pregled.php"><input type="hidden" name="id" value="<?php echo $id;?>"><input type="submit" value="Pregled">&nbsp</form></a></li>
<li><form action="pozivi.php"><input type="hidden" name="id" value="<?php echo $id;?>"><input type="submit" value="Pozivi">&nbsp</form></a></li>
<li><form action="treninzi.php"><input type="hidden" name="id" value="<?php echo $id;?>"><input type="submit" value="Treninzi">&nbsp</form></a></li>
</ul>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
	<br>	
	<span><?php echo "Volonter ID: <b>" . $id . "<b/>";?>
	<br><br>	
	<input type="submit" name="submit" value="Sačuvaj promene">
	<br><br>	
	<div class='heading'><div class='title'>1. Lične informacije</div></div>
	<table>
	  <tr>
	  <input style='width:300' class="field-divided" type="hidden" name="id" value="<?php echo $id;?>">
		<td style='width:300'>Ime*:</td>
		<td><input style='width:300' class="field-divided" type="text" name="ime" value="<?php echo $ime;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $imeErr;?></span></td>
	  </tr>
	  <tr>
		<td style='width:300'>Prezime*:</td>
		<td><input style='width:300' type="text" name="prezime" value="<?php echo $prezime;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $prezimeErr;?></span></td>
	  </tr>
	  <tr>
		<td style='width:300'>Ime roditelja:</td>
		<td><input style='width:300' type="text" name="roditelj" value="<?php echo $roditelj;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $roditeljErr;?></span></td>
	  </tr>
	   <tr>
		<td style='width:300'>Datum Rođenja (gggg-mm-dd):</td>
		<td><input style='width:300' type="text" name="datum_rodjenja" value="<?php echo $datum_rodjenja;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $datum_rodjenjaErr;?></span></td>
	  </tr>
	  <tr>
	    <td style='width:300'>Mesto rođenja:</td>
		<td><input style='width:300' type="text" name="mesto_rodjenja" value="<?php echo $mesto_rodjenja;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $mesto_rodjenjaErr;?></span></td>
	  </tr>
	  <tr>
	    <td style='width:300'>JMBG/Pasoš:</td>
		<td><input style='width:300' type="text" name="jmbg_pasos" value="<?php echo $jmbg_pasos;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $jmbg_pasosErr;?></span></td>
	  </tr>
	  <tr>
		<td style='width:300'>Zanimanje:</td>
		<td><input style='width:300' type="text" name="zanimanje" value="<?php echo $zanimanje;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $zanimanjeErr;?></span></td>
	  </tr>
	  <tr>
		<td style='width:300'>Ime kompanije/fakulteta/škole:</td>
		<td><input style='width:300' type="text" name="kompanija" value="<?php echo $kompanija;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $kompanijaErr;?></span></td>
	  </tr>
	</table>
	<div class='heading'><div class='title'>2. Državljanstvo Republike Srbije*</div></div>
	<table>
	  	<tr>
		<td>
			<input type="radio" name="drzavljanstvo" value="Da" <?php if (isset($drzavljanstvo) && $drzavljanstvo == 'Da')  echo ' checked="checked"';?>>Da <input type="radio" name="drzavljanstvo" value="Ne" <?php if (isset($drzavljanstvo) && $drzavljanstvo == 'Ne')  echo ' checked="checked"';?>>Ne
		</td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $drzavljanstvoErr;?></span></td>
	 </tr>
	</table>
	<div class='heading'><div class='title'>3. Adresa</div></div>
	<table>
	  <tr>
		<td style='width:300'>Ulica i broj:</td>
		<td><input style='width:300' type="text" name="ulica_broj" value="<?php echo $ulica_broj;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $ulicaErr;?></span></td>
	  </tr>
	   <tr>
		<td style='width:300'>Grad:</td>
		<td><input style='width:300' type="text" name="grad" value="<?php echo $grad;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $gradErr;?></span></td>
	  </tr>
	  <tr>
		<td style='width:300'>Poštanski broj:</td>
		<td><input style='width:300' type="text" name="postanski_broj" value="<?php echo $postanski_broj;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $postanski_brojErr;?></span></td>
	  </tr>
	  <tr>
		<td style='width:300'>Država:</td>
		<td><input style='width:300' type="text" name="drzava" value="<?php echo $drzava;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $drzavaErr;?></span></td>
	  </tr>
	  <tr>
		<td style='width:300'>Trenutna adresa:</td>
		<td><input style='width:300' type="text" name="adresa" value="<?php echo $adresa;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $trenutna_adresaErr;?></span></td>
	  </tr>
	</table>
	<div class='heading'><div class='title'>4. Kontakt informacije</div></div>
	<table>
	<tr>
		<td style='width:300'>E-mail*:</td>
		<td><input style='width:300' type="text" name="email" value="<?php echo $email;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $emailErr;?></span></td>
	</tr>
	<tr>
		<td style='width:300'>Fiksni telefon:</td>
		<td><input style='width:300' type="text" name="fiksni" value="<?php echo $fiksni;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $fiksniErr;?></span></td>
	</tr>	
	<tr>
		<td style='width:300'>Mobilni telefon*:</td>
		<td><input style='width:300' type="text" name="mobilni" value="<?php echo $mobilni;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $mobilniErr;?></span></td>
	</tr>	
	<tr>
		<td style='width:300'>Jezik komunikacije (maternji):</td>
		<td><input style='width:300' type="text" name="maternji_jezik" value="<?php echo $maternji_jezik;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $maternji_jezikErr;?></span></td>
	</tr>	
	</table>
	<div class='heading'><div class='title'>5. Veštine</div></div>
	<br>
	<table>
	<tr>
		<td style='width:300'>Engleski:</td>
		<td><select name="engleski">
			<option value="Nema znanje" <?php if (isset($engleski) && $engleski == 'Nema znanje') echo ' selected="selected"';?>>Nema znanje</option>
			<option value="Elementarno" <?php if (isset($engleski) && $engleski == 'Elementarno') echo ' selected="selected"';?>>Elementarno</option>
			<option value="Nizi srednji" <?php if (isset($engleski) && $engleski == 'Nizi srednji') echo ' selected="selected"';?>>Niži srednji</option>
			<option value="Visi srednji" <?php if (isset($engleski) && $engleski == 'Visi srednji') echo ' selected="selected"';?>>Viši srednji</option>
			<option value="Nizi napredni" <?php if (isset($engleski) && $engleski == 'Nizi napredni') echo ' selected="selected"';?>>Niži napredni</option>
			<option value="Visi napredni" <?php if (isset($engleski) && $engleski == 'Visi napredni') echo ' selected="selected"';?>>Viši napredni</option>
		</select>
		</td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $engleskiErr;?></span></td>
	</tr>
	<tr>
		<td style='width:300'>Francuski:</td>
		<td><select name="francuski">
			<option value="Nema znanje" <?php if (isset($francuski) && $francuski == 'Nema znanje') echo ' selected="selected"';?>>Nema znanje</option>
			<option value="Elementarno" <?php if (isset($francuski) && $francuski == 'Elementarno') echo ' selected="selected"';?>>Elementarno</option>
			<option value="Nizi srednji" <?php if (isset($francuski) && $francuski == 'Nizi srednji') echo ' selected="selected"';?>>Niži srednji</option>
			<option value="Visi srednji" <?php if (isset($francuski) && $francuski == 'Visi srednji') echo ' selected="selected"';?>>Viši srednji</option>
			<option value="Nizi napredni" <?php if (isset($francuski) && $francuski == 'Nizi napredni') echo ' selected="selected"';?>>Niži napredni</option>
			<option value="Visi napredni" <?php if (isset($francuski) && $francuski == 'Visi napredni') echo ' selected="selected"';?>>Viši napredni</option>
		</select>
		</td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $francuskiErr;?></span></td>
	</tr>
	<tr>
		<td style='width:300'>Nemački:</td>
		<td><select name="nemacki">
			<option value="Nema znanje" <?php if (isset($nemacki) && $nemacki == 'Nema znanje') echo ' selected="selected"';?>>Nema znanje</option>
			<option value="Elementarno" <?php if (isset($nemacki) && $nemacki == 'Elementarno') echo ' selected="selected"';?>>Elementarno</option>
			<option value="Nizi srednji" <?php if (isset($nemacki) && $nemacki == 'Nizi srednji') echo ' selected="selected"';?>>Niži srednji</option>
			<option value="Visi srednji" <?php if (isset($nemacki) && $nemacki == 'Visi srednji') echo ' selected="selected"';?>>Viši srednji</option>
			<option value="Nizi napredni" <?php if (isset($nemacki) && $nemacki == 'Nizi napredni') echo ' selected="selected"';?>>Niži napredni</option>
			<option value="Visi napredni" <?php if (isset($nemacki) && $nemacki == 'Visi napredni') echo ' selected="selected"';?>>Viši napredni</option>
		</select>
		</td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $nemackiErr;?></span></td>
	</tr>
	<tr>
		<td style='width:300'>Ostali jezici:</td>
		<td><input style='width:300' type="text" name="ostalo_jezik" value="<?php echo $ostalo_jezik;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $ostalo_jezikErr;?></span></td>
	</tr>
	</table>
	<table>
	<tr>
		<td style='width:300'>Word:</td>
		<td><select name="word">
			<option value="Slabo" <?php if (isset($word) && $word == 'Slabo') echo ' selected="selected"';?>>Slabo</option>
			<option value="Osnovno" <?php if (isset($word) && $word == 'Osnovno') echo ' selected="selected"';?>>Osnovno</option>
			<option value="Srednje" <?php if (isset($word) && $word == 'Srednje') echo ' selected="selected"';?>>Srednje</option>
			<option value="Napredno" <?php if (isset($word) && $word == 'Napredno') echo ' selected="selected"';?>>Napredno</option>
		</select>
		</td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $wordErr;?></span></td>
	</tr>
	<tr>
		<td style='width:300'>Excel:</td>
		<td><select name="excel">
			<option value="Slabo" <?php if (isset($excel) && $excel == 'Slabo') echo ' selected="selected"';?>>Slabo</option>
			<option value="Osnovno" <?php if (isset($excel) && $excel == 'Osnovno') echo ' selected="selected"';?>>Osnovno</option>
			<option value="Srednje" <?php if (isset($excel) && $excel == 'Srednje') echo ' selected="selected"';?>>Srednje</option>
			<option value="Napredno" <?php if (isset($excel) && $excel == 'Napredno') echo ' selected="selected"';?>>Napredno</option>
		</select>
		</td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $excelErr;?></span></td>
	</tr>	
	<tr>
		<td style='width:300'>Internet:</td>
		<td><select name="internet">
			<option value="Slabo" <?php if (isset($internet) && $internet == 'Slabo')  echo ' selected="selected"';?>>Slabo</option>
			<option value="Osnovno" <?php if (isset($internet) && $internet == 'Osnovno')  echo ' selected="selected"';?>>Osnovno</option>
			<option value="Srednje" <?php if (isset($internet) && $internet == 'Srednje')  echo ' selected="selected"';?>>Srednje</option>
			<option value="Napredno" <?php if (isset($internet) && $internet == 'Napredno')  echo ' selected="selected"';?>>Napredno</option>
		</select>
		</td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $internetErr;?></span></td>
	</tr>	
	<tr>
		<td style='width:300'>Ostali programi:</td>
		<td><input style='width:300' type="text" name="ostalo_racunari" value="<?php echo $ostalo_racunari;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $ostalo_racunariErr;?></span></td>
	</tr>	
	</table>
	<div class='heading'><div class='title'>6. O volontiranju</h2></div></div>
	<table>
	<tr>
		<td style='width:200'>Prethodno volontiranje*:</td>
		<td>
			<input type="radio" name="prethodno_volontiranje" value="Da" <?php if (isset($prethodno_volontiranje) && $prethodno_volontiranje == 'Da')  echo ' checked="checked"';?>>Da <input type="radio" name="prethodno_volontiranje" value="Ne" <?php if (isset($prethodno_volontiranje) && $prethodno_volontiranje == 'Ne')  echo ' checked="checked"';?>>Ne
		</td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $prethodno_volontiranjeErr;?></span></td>
	</tr>
	<tr>
		<td style='width:200'>Moje volontersko iskustvo:</td>
		<td><input style='width:300' type="text" name="ostalo_volontiranje" value="<?php echo $ostalo_volontiranje;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $ostalo_volontiranjeErr;?></span></td>
	</tr>	
	<tr>
		<td style='width:200'>Volontiraću*:</td>
		<td><br>
			<input type="radio" name="vreme_volontiranje" value="Tokom citavog projekta" <?php if (isset($vreme_volontiranje) && $vreme_volontiranje == 'Tokom citavog projekta')  echo ' checked="checked"';?>>Tokom čitavog projekta uključujući i promotivne aktivnosti<br> 
			<input type="radio" name="vreme_volontiranje" value="Samo za vreme prventstva" <?php if (isset($vreme_volontiranje) && ($vreme_volontiranje) == 'Samo za vreme prventstva')  echo ' checked="checked"';?>>Samo za vreme Evropskog prvenstva 08.01 - 24.01.2016.
		</td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $vreme_volontiranjeErr;?></span></td>
	</tr>
	<tr>
		<td style='width:200'><br>Konfekcijski broj*:</td>
		<td><br>
			<input type="radio" name="konfekcijski_broj" value="XS" <?php if (isset($konfekcijski_broj) && $konfekcijski_broj == 'XS')  echo ' checked="checked"';?>>XS
			<input type="radio" name="konfekcijski_broj" value="S" <?php if (isset($konfekcijski_broj) && $konfekcijski_broj == 'S')  echo ' checked="checked"';?>>S
			<input type="radio" name="konfekcijski_broj" value="M" <?php if (isset($konfekcijski_broj) && $konfekcijski_broj == 'M')  echo ' checked="checked"';?>>M
			<input type="radio" name="konfekcijski_broj" value="L" <?php if (isset($konfekcijski_broj) && $konfekcijski_broj == 'L')  echo ' checked="checked"';?>>L
			<input type="radio" name="konfekcijski_broj" value="XL" <?php if (isset($konfekcijski_broj) && $konfekcijski_broj == 'XL')  echo ' checked="checked"';?>>XL
			<input type="radio" name="konfekcijski_broj" value="XXL" <?php if (isset($konfekcijski_broj) && $konfekcijski_broj == 'XXL')  echo ' checked="checked"';?>>XXL
			<input type="radio" name="konfekcijski_broj" value="XXXL" <?php if (isset($konfekcijski_broj) && $konfekcijski_broj == 'XXXL')  echo ' checked="checked"';?>>XXXL
		</td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $konfekcijski_brojErr;?></span></td>
	</tr>
	</table>
	<div class='heading'><div class='title'>7. Zapažanja i sektor</h2></div></div>
	<table>
	<tr>
		<td style='width:300'>Ocena:</td>
		<td><select name="ocena">
			<option value=NULL <?php if (isset($ocena) && $ocena == '') echo ' selected="selected"';?>>0</option>
			<option value="1" <?php if (isset($ocena) && $ocena == '1') echo ' selected="selected"';?>>1</option>
			<option value="2" <?php if (isset($ocena) && $ocena == '2') echo ' selected="selected"';?>>2</option>
			<option value="3" <?php if (isset($ocena) && $ocena == '3') echo ' selected="selected"';?>>3</option>
			<option value="4" <?php if (isset($ocena) && $ocena == '4') echo ' selected="selected"';?>>4</option>
			<option value="5" <?php if (isset($ocena) && $ocena == '5') echo ' selected="selected"';?>>5</option>
			<option value="6" <?php if (isset($ocena) && $ocena == '6') echo ' selected="selected"';?>>6</option>
			<option value="7" <?php if (isset($ocena) && $ocena == '7') echo ' selected="selected"';?>>7</option>
			<option value="8" <?php if (isset($ocena) && $ocena == '8') echo ' selected="selected"';?>>8</option>
			<option value="9" <?php if (isset($ocena) && $ocena == '9') echo ' selected="selected"';?>>9</option>
			<option value="10" <?php if (isset($ocena) && $ocena == '10') echo ' selected="selected"';?>>10</option>			
		</select>
		</td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $ocenaErr;?></span></td>
	</tr>
	<tr>
		<td style='width:300'>Zapažanja:</td>
		<td><textarea style='width:300; resize: none;'  name="zapazanja" rows="5" cols="40"><?php echo $zapazanja;?></textarea></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $zapazanjaErr;?></span></td>
	 </tr>
	<tr>
		<td style='width:300'>Sektor:</td>
		<td><select name="sektor">
			<?php 
			$sql_sektor = "SELECT * FROM sektori ORDER BY naziv ASC";
			$result = $connection->query($sql_sektor);
			while($row = $result->fetch_assoc()) {
			?>
			<option value="<?php echo $row['naziv']; ?>" <?php if (isset($sektor) && $sektor == $row['naziv']) echo ' selected="selected"';?>><?php echo $row['naziv']; ?></option>
			<?php
			}
			?>
		</select>
		</td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $sektorErr;?></span></td>
	</tr>		
	
	</table>
	<br>
	<input type="submit" name="submit" value="Sačuvaj promene">
	</form>
</div>
	</body>
	</html>
	<?php
	mysqli_close($connection);
	?>
