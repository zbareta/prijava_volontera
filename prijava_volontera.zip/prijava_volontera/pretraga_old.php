<?php 
require_once("includes/db_connection.php");
require_once("includes/functions.php"); ?>
<?php include("includes/profile.php");?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="includes/kickstart/js/kickstart.js"></script> <!-- KICKSTART -->


<html lang="en">
	<head>
		<meta charset="utf8">	
		<link rel="stylesheet" href="includes/kickstart/css/kickstart.css" media="all" />
		<title>Volonteri - Evropsko Atletsko Prventstvo U Dvorani Beograd 2017</title>
	</head>
	<body>
	
	<?php
	//Ako ima submita - uzima promenjive iz forme, ako nema - uzima prazan string kao default
	$rows = 0;
	if ($_SERVER["REQUEST_METHOD"] == "POST"){
		$ime = test_input($_POST["ime"]);
		$prezime = test_input($_POST["prezime"]);
		$email = test_input($_POST["email"]);
		$id = test_input($_POST["id"]);
		$grad = test_input($_POST["grad"]);
		$datum_rodjenja = test_input($_POST["datum_rodjenja"]);
	}
	else{
		$ime = $prezime = $email = $id = $grad = $datum_rodjenja = ""; 
	}
	?>
	<!-- Forma za pretragu -->
	<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
	<table>
		<tr>
			<td>ID:</td>
			<td> <input type="text" name="id" value="<?php echo $id;?>"></td>
			<td>Ime:</td>
			<td> <input type="text" name="ime" value="<?php echo $ime;?>"></td>
			<td>Prezime:</td>
			<td><input type="text" name="prezime" value="<?php echo $prezime;?>"></td>
		</tr>
		<tr>
			<td>Datum rođenja (gggg-mm-dd):</td>
			<td><input type="text" name="datum_rodjenja" value="<?php echo $datum_rodjenja;?>"></td>
			<td>Grad:</td>
			<td><input type="text" name="grad" value="<?php echo $grad;?>"></td>
			<td>E-mail:</td>
			<td><input type="text" name="email" value="<?php echo $email;?>"></td>
		</tr>
  	</table>
<ul class="menu">
<li><input type="submit" name="submit" value="Pronađi">&nbsp </form></li>
<li><form action="clear.php"><input type="submit" value="Očisti filtere">&nbsp </form></a></li>
<li><form action="excel.php" method="post">
<input type="hidden" name="id" value="<?php echo $id;?>">
<input type="hidden" name="ime" value="<?php echo $ime;?>">
<input type="hidden" name="prezime" value="<?php echo $prezime;?>">
<input type="hidden" name="datum_rodjenja" value="<?php echo $datum_rodjenja;?>">
<input type="hidden" name="grad" value="<?php echo $grad;?>">
<input type="hidden" name="email" value="<?php echo $email;?>">
<input type="submit" value="Export u Excel">&nbsp
</form></li>
<li><?php if($login_session == "admin"){?><form action="sektori.php" method="post"><input type="submit" value="Dodavanje sektora"><?php } ?>&nbsp </form><li>
<li><?php if($login_session == "admin"){?><form action="korisnici.php" method="post"><input type="submit" value="Kreiranje korisnika"><?php } ?></form><li>
</ul>
	<br>
	<?php
	//Prikaz rezultata search-a u tabeli
	if ($_SERVER["REQUEST_METHOD"] == "POST"){
		$sql = "SELECT id, ime, prezime, datum_rodjenja, grad, mobilni, email FROM volonteri WHERE id LIKE '%$id%' AND ime LIKE '%$ime%' AND prezime LIKE '%$prezime%' AND datum_rodjenja LIKE '%$datum_rodjenja%' AND grad LIKE '%$grad%' AND email LIKE '%$email%' ORDER BY ime ASC";
		$result = $connection->query($sql);
		if (($result->num_rows) > 0){
		echo $result->num_rows . " volonter(a) prikazano<br><br>";}
		if ($result->num_rows > 0) { ?>
		<table class='striped tight'>
			<tr><th>ID</th>
				<th>Ime</th>
				<th>Prezime</th>
				<th>Datum rođenja</th>
				<th>Grad</th>
				<th>Telefon</th>
				<th>E-Mail</th>
				<th>Pregled</th>
				<th>Izmena</th>
				<th>Brisanje</th>
				<th>Pozivi</th>
				<th>Treninzi</th></tr>
			<?php
			while($row = $result->fetch_assoc()) {
				?>
			<tr><td><?php echo $row['id']?></td>
				<td><?php echo $row["ime"]?></td>
				<td><?php echo $row["prezime"]?></td>
				<td><?php echo $row["datum_rodjenja"]?></td>
				<td><?php echo $row["grad"]?></td>
				<td><?php echo $row["mobilni"]?></td>
				<td><?php echo $row["email"]?></td>
				<td><a href="pregled.php?id=<?php echo $row['id'] ?>"><i class='fa fa-eye'>Pregled</i></a></td>
				<td><a href="izmena.php?id=<?php echo $row['id'] ?>"><i class='fa fa-pencil'>Izmena</i></a></td>
				<td><a href="brisanje.php?id=<?php echo $row['id'] ?>" onClick="return confirm('Da li ste sigurni da želite obrisati volontera?')"><i class='fa fa-trash' >Brisanje</i></a></td>
				<td><a href="pozivi.php?id=<?php echo $row['id'] ?>"><i class='fa fa-phone'>Dodaj poziv</i></a></td>
				<td><a href="treninzi.php?id=<?php echo $row['id'] ?>"><i class='fa fa-book'>Dodaj trening</i></a></td>
			</tr>
			<?php $rows += 1;}?>
		</table>
		<?php
		}
		echo "<br>" . $rows . " volonter(a) prikazano";
	}
	else{
	//Prikaz svih rezuultata ako nema search-a
	$sql = "SELECT id, ime, prezime, mobilni, email, grad, datum_rodjenja FROM volonteri ORDER BY ime ASC";
	$result = $connection->query($sql);
	echo $result->num_rows . " volonter(a) prikazano<br><br>";
	if ($result->num_rows > 0) {?>
		<table class='striped tight'>
			<tr><th>ID</th>
				<th>Ime</th>
				<th>Prezime</th>
				<th>Datum rođenja</th>
				<th>Grad</th>
				<th>Telefon</th>
				<th>E-Mail</th>
				<th>Pregled</th>
				<th>Izmena</th>
				<th>Brisanje</th>
				<th>Pozivi</th>
				<th>Treninzi</th></tr>
			<?php
			while($row = $result->fetch_assoc()) {
				?>
			<tr><td><?php echo $row['id']?></td>
				<td><?php echo $row["ime"]?></td>
				<td><?php echo $row["prezime"]?></td>
				<td><?php echo $row["datum_rodjenja"]?></td>
				<td><?php echo $row["grad"]?></td>
				<td><?php echo $row["mobilni"]?></td>
				<td><?php echo $row["email"]?></td>
				<td><a href="pregled.php?id=<?php echo $row['id'] ?>"><i class='fa fa-eye'>Pregled</i></a></td>
				<td><a href="izmena.php?id=<?php echo $row['id'] ?>"><i class='fa fa-pencil'>Izmena</i></a></td>
				<td><a href="brisanje.php?id=<?php echo $row['id'] ?>" onClick="return confirm('Da li ste sigurni da želite obrisati volontera?')"><i class='fa fa-trash' >Brisanje</i></a></td>
				<td><a href="pozivi.php?id=<?php echo $row['id'] ?>"><i class='fa fa-phone'>Dodaj poziv</i></a></td>
				<td><a href="treninzi.php?id=<?php echo $row['id'] ?>"><i class='fa fa-book'>Dodaj trening</i></a></td>
			</tr>
			<?php $rows += 1;}?>
		</table>
		<?php
	}
	echo "<br>" . $rows . " volonter(a) prikazano";
	}
	?>
	</body>
</html>
	<?php
	mysqli_close($connection);
	?>