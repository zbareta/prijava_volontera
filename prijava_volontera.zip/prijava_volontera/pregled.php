<?php 
require_once("includes/db_connection.php");
include("includes/profile.php");
require_once("includes/functions.php"); 
require_once("includes/print.php");?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="includes/kickstart/js/kickstart.js"></script> <!-- KICKSTART -->
	<div id="content">
<html lang="en">
	<head>
	<meta charset="utf8">
		<link rel="stylesheet" href="includes/kickstart/css/kickstart.css" media="all" />
		<title>Pregled volontera</title>
	</head>
<?php
//Proverava da li je prosledjen ID
if (empty($_GET["id"])){
	$id = "";
}
else{
//Izvršava upit i dodeljuje vrednosti prom.
	$id = test_input($_GET["id"]);}?>
	<body>
	<ul class="menu" id="menuhide">
	<li><form action="pretraga.php"><input type="submit" value="Pretraga">&nbsp</form></a></li>
	<li><form action="izmena.php"><input type="hidden" name="id" value="<?php echo $id;?>"><input type="submit" value="Izmene">&nbsp</form></a></li>
	<li><form action="pozivi.php"><input type="hidden" name="id" value="<?php echo $id;?>"><input type="submit" value="Pozivi">&nbsp</form></a></li>
	<li><form action="treninzi.php"><input type="hidden" name="id" value="<?php echo $id;?>"><input type="submit" value="Treninzi">&nbsp</form></a></li>
	<li><input type="button" value="Štampa" onclick="printpage()"/>&nbsp</li>
	</ul>

<?php
	$sql = "SELECT * FROM volonteri WHERE id='$id'";
	$result = $connection->query($sql);
	$row = $result->fetch_assoc();
	if (empty($row["ime"])){$ime="";}else{
	$ime = $row["ime"];}
	if (empty($row["prezime"])){$prezime="";}else{
	$prezime = $row["prezime"];}
	if (empty($row["email"])){$email="";}else{
	$email = $row["email"];}
	if (empty($row["roditelj"])){$roditelj="";}else{
	$roditelj = $row["roditelj"];}
	if (empty($row["datum_rodjenja"])){$datum_rodjenja="";}else{
	$datum_rodjenja = $row["datum_rodjenja"];}
	if (empty($row["mesto_rodjenja"])){$mesto_rodjenja="";}else{
	$mesto_rodjenja = $row["mesto_rodjenja"];}
	if (empty($row["jmbg_pasos"])){$jmbg_pasos="";}else{
	$jmbg_pasos = $row["jmbg_pasos"];}
	if (empty($row["zanimanje"])){$zanimanje="";}else{
	$zanimanje = $row["zanimanje"];}
	if (empty($row["kompanija"])){$kompanija="";}else{
	$kompanija = $row["kompanija"];}
	if (empty($row["drzavljanstvo"])){$drzavljanstvo="";}else{
	$drzavljanstvo = $row["drzavljanstvo"];}
	if (empty($row["ulica_broj"])){$ulica_broj="";}else{
	$ulica_broj = $row["ulica_broj"];}
	if (empty($row["grad"])){$grad="";}else{
	$grad = $row["grad"];}
	if (empty($row["postanski_broj"])){$postanski_broj="";}else{
	$postanski_broj = $row["postanski_broj"];}
	if (empty($row["drzava"])){$drzava="";}else{
	$drzava = $row["drzava"];}
	if (empty($row["adresa"])){$adresa="";}else{
	$adresa = $row["adresa"];}
	if (empty($row["email"])){$email="";}else{
	$email = $row["email"];}
	if (empty($row["fiksni"])){$fiksni="";}else{
	$fiksni = $row["fiksni"];}
	if (empty($row["mobilni"])){$mobilni="";}else{
	$mobilni = $row["mobilni"];}
	if (empty($row["maternji_jezik"])){$maternji_jezik="";}else{
	$maternji_jezik = $row["maternji_jezik"];}
	if (empty($row["engleski"])){$engleski="";}else{
	$engleski = $row["engleski"];}
	if (empty($row["francuski"])){$francuski="";}else{
	$francuski = $row["francuski"];}
	if (empty($row["nemacki"])){$nemacki="";}else{
	$nemacki = $row["nemacki"];}
	if (empty($row["ostalo_jezik"])){$ostalo_jezik="";}else{
	$ostalo_jezik = $row["ostalo_jezik"];}
	if (empty($row["word"])){$word="";}else{
	$word = $row["word"];}
	if (empty($row["excel"])){$excel="";}else{
	$excel = $row["excel"];}
	if (empty($row["internet"])){$internet="";}else{
	$internet = $row["internet"];}
	if (empty($row["ostalo_racunari"])){$ostalo_racunari="";}else{
	$ostalo_racunari = $row["ostalo_racunari"];}
	if (empty($row["prethodno_volontiranje"])){$prethodno_volontiranje="";}else{
	$prethodno_volontiranje = $row["prethodno_volontiranje"];}
	if (empty($row["ostalo_volontiranje"])){$ostalo_volontiranje="";}else{
	$ostalo_volontiranje = $row["ostalo_volontiranje"];}
	if (empty($row["vreme_volontiranje"])){$vreme_volontiranje="";}else{
	$vreme_volontiranje = $row["vreme_volontiranje"];}
	if (empty($row["konfekcijski_broj"])){$konfekcijski_broj="";}else{
	$konfekcijski_broj = $row["konfekcijski_broj"];}
	if (empty($row["ocena"])){$ocena="";}else{
	$ocena = $row["ocena"];}
	if (empty($row["sektor"])){$sektor="";}else{
	$sektor = $row["sektor"];}
		if (empty($row["zapazanja"])){$zapazanja="";}else{
	$zapazanja = $row["zapazanja"];}
																			
?>
	
	<br>
	<span><?php echo "Volonter ID: <b>" . $id . "<b/>";?>
	<br><br>
	<div class='heading'><div class='title'>1. Lične informacije</div></div>
	<table>
	  <tr>
	  <input style='width:300' class="field-divided" type="hidden" name="id" value="<?php echo $id;?>">
		<td style='width:300'>Ime:</td>
		<td><span><?php echo $ime;?></td>
	  </tr>
	  <tr>
		<td style='width:300'>Prezime:</td>
		<td><span><?php echo $prezime;?></span></td>
	  </tr>
	  <tr>
		<td style='width:300'>Ime roditelja:</td>
		<td><span><?php echo $roditelj;?></span></td>
	  </tr>
	   <tr>
		<td style='width:300'>Datum Rođenja (gggg-mm-dd):</td>
		<td><span><?php echo $datum_rodjenja;?></span></td>
	  </tr>
	  <tr>
	    <td style='width:300'>Mesto rođenja:</td>
		<td><span><?php echo $mesto_rodjenja;?></span></td>
	  </tr>
	  <tr>
	    <td style='width:300'>JMBG/Pasoš:</td>
		<td><span><?php echo $jmbg_pasos;?></span></td>
	  </tr>
	  <tr>
		<td style='width:300'>Zanimanje:</td>
		<td><span><?php echo $zanimanje;?></span></td>
	  </tr>
	  <tr>
		<td style='width:300'>Ime kompanije/fakulteta/škole:</td>
		<td><span><?php echo $kompanija;?></span></td>
	  </tr>
	</table>
	<div class='heading'><div class='title'>2. Državljanstvo Republike Srbije</div></div>
	<table>
	   <tr>
		<td style='width:300'>Državljanstvo RS:</td>
		<td><span><?php echo $drzavljanstvo;?></span></td>
	  </tr>
	</table>
	<div class='heading'><div class='title'>3. Adresa</div></div>
	<table>
	  <tr>
		<td style='width:300'>Ulica i broj:</td>
		<td><span><?php echo $ulica_broj;?></span></td>
	  </tr>
	   <tr>
		<td style='width:300'>Grad:</td>
		<td><span><?php echo $grad;?></span></td>
	  </tr>
	  <tr>
		<td style='width:300'>Poštanski broj:</td>
		<td><span><?php echo $postanski_broj;?></span></td>
	  </tr>
	  <tr>
		<td style='width:300'>Država:</td>
		<td><span><?php echo $drzava;?></span></td>
	  </tr>
	  <tr>
		<td style='width:300'>Trenutna adresa:</td>
		<td><span><?php echo $adresa;?></span></td>
	  </tr>
	</table>
	<div class='heading'><div class='title'>4. Kontakt informacije</div></div>
	<table>
	<tr>
		<td style='width:300'>E-mail:</td>
		<td><span><?php echo $email;?></span></td>
	</tr>
	<tr>
		<td style='width:300'>Fiksni telefon:</td>
		<td><span><?php echo $fiksni;?></span></td>
	</tr>	
	<tr>
		<td style='width:300'>Mobilni telefon:</td>
		<td><span><?php echo $mobilni;?></span></td>
	</tr>	
	<tr>
		<td style='width:300'>Jezik komunikacije (maternji):</td>
		<td><span><?php echo $maternji_jezik;?></span></td>
	</tr>	
	</table>
	<div class='heading'><div class='title'>5. Veštine</div></div>
	<br>
	<table>
	<tr>
	    <td style='width:300'>Engleski:</td>
		<td><span><?php echo $engleski;?></span></td>
	  </tr>
	<tr>
	    <td style='width:300'>Francuski:</td>
		<td><span><?php echo $francuski;?></span></td>
	</tr>
	<tr>
	    <td style='width:300'>Nemački:</td>
		<td><span><?php echo $nemacki;?></span></td>
	</tr>
	<tr>
		<td style='width:300'>Ostali jezici:</td>
		<td><span><?php echo $ostalo_jezik;?></span></td>
	</tr>
	</table>
	<table>
	<tr>
	    <td style='width:300'>Word:</td>
		<td><span><?php echo $word;?></span></td>
	</tr>
	<tr>
	    <td style='width:300'>Excel:</td>
		<td><span><?php echo $excel;?></span></td>
	</tr>	
	<tr>
	    <td style='width:300'>Internet:</td>
		<td><span><?php echo $internet;?></span></td>
	</tr>
	<tr>
		<td style='width:300'>Ostali programi:</td>
		<td><span><?php echo $ostalo_racunari;?></span></td>
	</tr>	
	</table>
	<div class='heading'><div class='title'>6. O volontiranju</h2></div></div>
	<table>
	<tr>
		<td style='width:300'>Prethodno volontiranje:</td>
		<td><span><?php echo $prethodno_volontiranje;?></span></td>
	</tr>	
	<tr>
		<td style='width:200'>Moje volontersko iskustvo:</td>
		<td><span><?php echo $ostalo_volontiranje;?></span></td>
	</tr>	
	<tr>
		<td style='width:300'>Volontiraću:</td>
		<td><span><?php echo $vreme_volontiranje;?></span></td>
	</tr>	
	<tr>
		<td style='width:300'>Konfekcijski broj:</td>
		<td><span><?php echo $konfekcijski_broj;?></span></td>
	</tr>
	</table>
	<div class='heading'><div class='title'>7. Zapažanja i sektor</h2></div></div>
	<table>
	<tr>
		<td style='width:300'>Ocena:</td>
		<td><span><?php echo $ocena;?></span></td>
	</tr>
	<tr>
		<td style='width:300'>Zapazanja:</td>
		<td><span><?php echo $zapazanja;?></span></td>
	</tr>	
	<tr>
		<td style='width:300'>Sektor:</td>
		<td><span><?php echo $sektor;?></span></td>
	</tr>
	</table>
	<div class='heading'><div class='title'>8. Pozivi</h2></div></div>
	<?php
	$sql = "SELECT * FROM pozivi WHERE volonteri_id = '$id'";
		$result = $connection->query($sql);
		$rows = 0;
	if ($result->num_rows > 0) {?>
    	<table class='striped tight'>
			<tr><th>Komentar</th>
				<th>Javio se</th>
				<th>Vreme poziva</th>
			<?php
			while($row = $result->fetch_assoc()) {
				?>
			<tr><td><?php echo $row['komentar']?></td>
				<td><?php echo $row["javio_se"]?></td>
				<td><?php echo $row["created"]?></td>
			</tr>
			<?php $rows += 1;} 		
			echo "<br>" . $rows . " poziv(a)";?>
			<br><br>
			<?php
			}else
			{echo "<br>Nema poziva za ovog volontera<br><br>";}?>
		</table>
		<div class='heading'><div class='title'>9. Treninzi</h2></div></div>
		<?php
$sql = "SELECT * FROM treninzi WHERE volonteri_id = '$id'";
		$result = $connection->query($sql);
		$rows = 0;
	if ($result->num_rows > 0) {?>
    	<table class='striped tight'>
			<tr><th>Vreme i komentar</th>
				<th>Datum treninga</th>
			<?php
			while($row = $result->fetch_assoc()) {
				?>
			<tr><td><?php echo $row['komentar']?></td>
				<td><?php echo $row["datum"]?></td>
			</tr>
			<?php $rows += 1;} 		
			echo "<br>" . $rows . " trening(a)";?>
			<br><br>
			<?php
			}else
			{echo " <br>Nema treninga za ovog volontera<br><br>";}?>
		</table>
</div>
	</body>
	</html>
	<?php
	mysqli_close($connection);
	?>
