<?php require_once("includes/db_connection.php"); ?>
<?php require_once("includes/functions.php"); ?>
<?php include("includes/profile.php");?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="includes/kickstart/js/kickstart.js"></script> <!-- KICKSTART -->
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="includes/kickstart/css/kickstart.css" media="all" />
<title>Sektori</title>
</head>
<body>
<?php
if($login_session !== "admin"){
mysqli_close($connection);
?><script>location.href = 'pretraga.php'</script>"<?php
}
?>
<div id="content">
<ul class="menu" id="printhide">
<li><form action="pretraga.php"><input type="submit" value="Pretraga">&nbsp</form></a></li>
</ul>
<br><br>

<?php
$naziv = "";
$nazivErr = "";
$id="";
$error = 0;

if (isset($_POST['submit'])) {
//naziv
if (empty($_POST["naziv"])){
		$nazivErr = "Obavezno polje";
		$error = 1;}
	else{
	$naziv = test_input($_POST["naziv"]);}

// Insert query
if($error == 0){
$sql = "INSERT INTO sektori (naziv) VALUES ('$naziv')";
if(mysqli_query($connection, $sql)){
 echo "<div class='notice success'><i class='icon-ok icon-large'></i> Uspešno unet sektor.<a href='#close' class='icon-remove'></a></div><br><br>";
$komentar = "";}
else{
    echo "Došlo je do grešeke: " . mysqli_error($connection);
}}}

//html forma
?>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
<table>
<tr>
	<td>
		Naziv sektora: 
	</td>
	<td>
	<input type="text" name="naziv" value="<?php echo $naziv;?>">
	</td>
	<td>
		<span style="color:red;"><?php echo $nazivErr;?></span>
	</td>
</tr>
</table>
<br>
<input type="submit" name="submit" value="Dodaj sektor">
</form>
<br><br>
<?php
$sql = "SELECT * FROM sektori WHERE naziv != '' ORDER BY naziv ASC" ;
		$result = $connection->query($sql);
		$rows = 0;
	if ($result->num_rows > 0) {?>
    	<table class='striped tight'>
			<tr><th>Sektor</th>
				<th>Brisanje</th>
			<?php
			while($row = $result->fetch_assoc()) {
				?>
			<tr><td><?php echo $row['naziv']?></td>
				<td><a href="brisanjesektora.php?id=<?php echo $row['id'] ?>" onClick="return confirm('Da li ste sigurni da želite obrisati sektor?')"><i class='fa fa-trash' >Brisanje</i></a></td>
			</tr>
			<?php $rows += 1;} 		
			echo "<br>" . $rows . " sektor(a) prikazan(o)";?>
			<br><br>
			<?php
			}else
			{echo "<br>Nema unetih sektora";}?>
		</table>

</div>	
</body>
</html>
	<?php
	mysqli_close($connection);
	?>