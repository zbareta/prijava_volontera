<?php require_once("includes/profile.php"); ?>
<?php
session_start();
mysqli_query($connection, $sql);
if(session_destroy()) // Destroying All Sessions
{
?><script>location.href = 'login.php'</script>"<?php
}
?>