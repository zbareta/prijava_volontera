<?php require_once("includes/db_connection.php"); ?>
<?php require_once("includes/functions.php"); ?>
<?php include("includes/profile.php");?>
<?php
$id = "";
if (isset($_GET['id']) && !empty($_GET['id'])){
// sql to delete a record
$id = test_input($_GET["id"]);
$sql = "DELETE FROM login WHERE id='$id'";
mysqli_query($connection, $sql);
mysqli_close($connection);}

?>
<meta http-equiv="refresh" content="0; url=korisnici.php" />
