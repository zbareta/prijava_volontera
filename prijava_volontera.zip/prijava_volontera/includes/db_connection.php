<?php
define ("DB_SERVER", "mysql");
define ("DB_USER", "dolphine_prijava");
define ("DB_PASS", "S1fr#oeddol");
define ("DB_NAME", "dolphine_prijavavolontera");
$connection = mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
	if (mysqli_connect_errno()){
		die("Database connection failed: " .  
			mysqli_connect_error() . 
			" (" . mysqli_connect_errno() . ")"
		);
	};
?>