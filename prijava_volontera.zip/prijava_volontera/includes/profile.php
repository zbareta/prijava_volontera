<?php include("includes/session.php");?>
<body>
<b id="log1hide">Korisnik: <i><?php echo $login_session; ?></i></b>
<b id="log2hide"><a href="logout.php"> (izloguj se)</a></b>
</div>
</body>
