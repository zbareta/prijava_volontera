<script type="text/javascript">
    function printpage() {
        var printLog1 = document.getElementById("log1hide"); 
		var printLog2 = document.getElementById("log2hide"); 
		var printMenu = document.getElementById("menuhide");
        printLog1.style.visibility = 'hidden';
		printLog2.style.visibility = 'hidden';
		printMenu.style.visibility = 'hidden';
        window.print()
        printLog1.style.visibility = 'Visible';
		printLog2.style.visibility = 'Visible';
		printMenu.style.visibility = 'Visible';
    }
</script>