<?php
require_once("includes/db_connection.php");

	if ($_SERVER["REQUEST_METHOD"] == "POST"){
		$ime = ($_POST["ime"]);
		$prezime = ($_POST["prezime"]);
		$email = ($_POST["email"]);
		$id = ($_POST["id"]);
		$grad = ($_POST["grad"]);
		$datum_rodjenja = ($_POST["datum_rodjenja"]);
	}
	else{
		$ime = $prezime = $email = $id = $grad = $datum_rodjenja = ""; 
	}	
// Create your database query
$sql = "SELECT id, ime, prezime, datum_rodjenja, grad, mobilni, email FROM volonteri WHERE id LIKE '%$id%' AND ime LIKE '%$ime%' AND prezime LIKE '%$prezime%' AND datum_rodjenja LIKE '%$datum_rodjenja%' AND grad LIKE '%$grad%' AND email LIKE '%$email%' ORDER BY ime ASC";  
// Execute the database query
$result = $connection->query($sql);
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=volonteri.xls");
header("Pragma: no-cache");
header ("Expires: 0");
require_once("includes/session.php");
?>
    <table width="100%" border="1">
        <tr>
            <td>
                <h1> ID Volontera</h1>
            </td>
			 <td>
                <h1> Ime</h1>
            </td>
			 <td>
                <h1> Prezime</h1>
            </td>
			 <td>
                <h1> Datum Rodjenja</h1>
            </td>
			 <td>
                <h1> Grad</h1>
            </td>
			 <td>
                <h1> Telefon</h1>
            </td>
			 <td>
                <h1> E-Mail</h1>
            </td>
        </tr>

   <?php while($row = $result->fetch_assoc()) {?>
        <tr>
            <td>
                <?php echo $row['id']; ?>
            </td>
			 <td>
                <?php echo $row['ime']; ?>
            </td>
			 <td>
                <?php echo $row['prezime']; ?>
            </td>
			    <td>
                <?php echo $row['datum_rodjenja']; ?>
            </td>
			<td>
                <?php echo $row['grad']; ?>
            </td>
			<td>
                <?php echo $row['mobilni']; ?>
            </td>
			 <td>
                <?php echo $row['email']; ?>
            </td>
        </tr>

    <?php } ?>

    </table>