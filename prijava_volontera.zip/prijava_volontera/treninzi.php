<?php require_once("includes/db_connection.php"); ?>
<?php require_once("includes/functions.php"); ?>
<?php include("includes/profile.php");?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="includes/kickstart/js/kickstart.js"></script> <!-- KICKSTART -->
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="includes/kickstart/css/kickstart.css" media="all" />
<title>Treninzi</title>
</head>
<body>
<?php
//Proverava da li je prosledjen ID
if (empty($_GET["id"])){
	$id = "";
}
else{
//Izvršava upit i dodeljuje vrednosti prom.
	$id = test_input($_GET["id"]);}?>
<div id="content">
<ul class="menu" id="printhide">
<li><form action="pretraga.php"><input type="submit" value="Pretraga">&nbsp</form></a></li>
<li><form action="pregled.php"><input type="hidden" name="id" value="<?php echo $id;?>"><input type="submit" value="Pregled">&nbsp</form></a></li>
<li><form action="izmena.php"><input type="hidden" name="id" value="<?php echo $id;?>"><input type="submit" value="Izmene">&nbsp</form></a></li>
<li><form action="pozivi.php"><input type="hidden" name="id" value="<?php echo $id;?>"><input type="submit" value="Pozivi">&nbsp</form></a></li>
</ul>
<br><br>

<?php
$error = 0;
$komentar = "";
$datum = "";
$komentarErr = "";
$datumErr = "";
$id="";
if (isset($_GET['id']) && !empty($_GET['id'])){
$id = test_input($_GET["id"]);}

if (isset($_POST['submit'])) {
//komentar
if (empty($_POST["komentar"])){
	$komentar = "";}
else{
$komentar = test_input($_POST["komentar"]);}

//datum
if (empty($_POST["datum"])){
		$datumErr = "Obavezno polje";
		$error = 1;}
	else{
	$datum = test_input($_POST["datum"]);}

// Insert query
if ($error == 0){
$sql = "INSERT INTO treninzi (komentar, datum, volonteri_id) VALUES ('$komentar', '$datum', '$id')";
if(mysqli_query($connection, $sql)){
 echo "<div class='notice success'><i class='icon-ok icon-large'></i> Uspešno zabeležen trening.<a href='#close' class='icon-remove'></a></div><br><br>";
$komentar = "";}
else{
    echo "Došlo je do grešeke: " . mysqli_error($connection);
}}}

//html forma
?>
<span><?php echo "Volonter ID: <b>" . $id . "<b/>";?>
<br><br>
<form action="treninzi.php?id=<?php echo $id?>" method="POST">
<table>
<input type="hidden" name="id" value="<?php echo $id;?>">
<tr>
	<td>
		Vreme i komentar: 
	</td>
	<td>
	<input type="text" name="komentar" value="<?php echo $komentar;?>">
	</td>
	<td>
		<span style="color:red;"><?php echo $komentarErr;?></span>
	</td>
</tr>
<tr>
	<td style='width:300'>Datum treninga (gggg-mm-dd):</td>
	<td><input style='width:300' type="text" name="datum" value="<?php echo $datum;?>"></td>
	<td><span style="background-color: #D33943;color: white;"><?php echo $datumErr;?></span></td>
</tr>
</table>
<br>
<input type="submit" name="submit" value="Dodaj trening">
</form>
<br><br>
<?php
$sql = "SELECT * FROM treninzi WHERE volonteri_id = '$id'";
		$result = $connection->query($sql);
		$rows = 0;
	if ($result->num_rows > 0) {?>
    	<table class='striped tight'>
			<tr><th>Komentar</th>
				<th>Datum treninga</th>
				<th>Brisanje</th>
			<?php
			while($row = $result->fetch_assoc()) {
				?>
			<tr><td><?php echo $row['komentar']?></td>
				<td><?php echo $row["datum"]?></td>
				<td><a href="brisanjetreninga.php?id=<?php echo $row['id'] ?>&vid=<?php echo $id ?>" onClick="return confirm('Da li ste sigurni da želite obrisati trening?')"><i class='fa fa-trash' >Brisanje</i></a></td>
			</tr>
			<?php $rows += 1;} 		
			echo "<br>" . $rows . " trening(a) prikazan(o)";?>
			<br><br>
			<?php
			}else
			{echo "Nema treninga za odabranog volontera";}?>
		</table>

</div>	
</body>
</html>
	<?php
	mysqli_close($connection);
	?>