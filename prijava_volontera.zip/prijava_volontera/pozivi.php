<?php require_once("includes/db_connection.php"); ?>
<?php require_once("includes/functions.php"); ?>
<?php include("includes/profile.php");?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="includes/kickstart/js/kickstart.js"></script> <!-- KICKSTART -->
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="includes/kickstart/css/kickstart.css" media="all" />
<title>Pozivi</title>
</head>
<body>
<?php
//Proverava da li je prosledjen ID
if (empty($_GET["id"])){
	$id = "";
}
else{
//Izvršava upit i dodeljuje vrednosti prom.
	$id = test_input($_GET["id"]);}?>
<div id="content">
<ul class="menu" id="printhide">
<li><form action="pretraga.php"><input type="submit" value="Pretraga">&nbsp</form></a></li>
<li><form action="pregled.php"><input type="hidden" name="id" value="<?php echo $id;?>"><input type="submit" value="Pregled">&nbsp</form></a></li>
<li><form action="izmena.php"><input type="hidden" name="id" value="<?php echo $id;?>"><input type="submit" value="Izmene">&nbsp</form></a></li>
<li><form action="treninzi.php"><input type="hidden" name="id" value="<?php echo $id;?>"><input type="submit" value="Treninzi">&nbsp</form></a></li>
</ul>
<br><br>

<?php
$komentar = $javio_se = "";
$komentarErr = $javio_seErr = "";
$id="";
if (isset($_GET['id']) && !empty($_GET['id'])){
$id = test_input($_GET["id"]);}

if (isset($_POST['submit'])) {
//komentar
if (empty($_POST["komentar"])){
	$komentar = "";}
else{
$komentar = test_input($_POST["komentar"]);}

//javio se
if (empty($_POST["javio_se"])){
	$javio_se = "";}
else{
$javio_se = test_input($_POST["javio_se"]);}

// Insert query
$sql = "INSERT INTO pozivi (komentar, javio_se, volonteri_id) VALUES ('$komentar', '$javio_se', '$id')";
if(mysqli_query($connection, $sql)){
 echo "<div class='notice success'><i class='icon-ok icon-large'></i> Uspešno zabeležen poziv.<a href='#close' class='icon-remove'></a></div><br><br>";
$komentar = $javio_se = "";}
else{
    echo "Došlo je do grešeke: " . mysqli_error($connection);
}}

//html forma
?>
<span><?php echo "Volonter ID: <b>" . $id . "<b/>";?>
<br><br>
<form action="pozivi.php?id=<?php echo $id?>" method="POST">
<table>
<input type="hidden" name="id" value="<?php echo $id;?>">
<tr>
	<td>
		Komentar: 
	</td>
	<td>
	<input type="text" name="komentar" value="<?php echo $komentar;?>">
	</td>
	<td>
		<span style="color:red;"><?php echo $komentarErr;?></span>
	</td>
</tr>
<tr>
	<td>
		Javio se:
	</td>
		<td>
			<input type="radio" name="javio_se" value="Ne" checked="checked">Ne<input type="radio" name="javio_se" value="Da">Da
		</td>
	<td>
		<span style="color:red;"><?php echo $javio_seErr;?></span>
	</td>
</tr>
</table>
<br>
<input type="submit" name="submit" value="Dodaj poziv">
</form>
<br><br>
<?php
$sql = "SELECT * FROM pozivi WHERE volonteri_id = '$id'";
		$result = $connection->query($sql);
		$rows = 0;
	if ($result->num_rows > 0) {?>
    	<table class='striped tight'>
			<tr><th>Komentar</th>
				<th>Javio se</th>
				<th>Vreme poziva</th>
				<th>Brisanje</th>
			<?php
			while($row = $result->fetch_assoc()) {
				?>
			<tr><td><?php echo $row['komentar']?></td>
				<td><?php echo $row["javio_se"]?></td>
				<td><?php echo $row["created"]?></td>
				<td><a href="brisanjepoziva.php?id=<?php echo $row['id'] ?>&vid=<?php echo $id ?>" onClick="return confirm('Da li ste sigurni da želite obrisati poziv?')"><i class='fa fa-trash' >Brisanje</i></a></td>
			</tr>
			<?php $rows += 1;} 		
			echo "<br>" . $rows . " poziv(a) prikazan(o)";?>
			<br><br>
			<?php
			}else
			{echo "Nema poziva za odabranog volontera";}?>
		</table>

</div>	
</body>
</html>
	<?php
	mysqli_close($connection);
	?>