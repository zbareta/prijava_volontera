<?php include("includes/profile.php");?>
<meta http-equiv="refresh" content="0; url=pretraga.php" />