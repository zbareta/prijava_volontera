<?php require_once("includes/db_connection.php"); ?>
<?php include("includes/profile.php");?>
<?php include("includes/password.php");?>
<?php require_once("includes/functions.php"); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="includes/kickstart/js/kickstart.js"></script> <!-- KICKSTART -->
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="includes/kickstart/css/kickstart.css" media="all" />
<title>Korisnici</title>
</head>
<?php
if($login_session !== "admin"){
mysqli_close($connection);
?><script>location.href = 'pretraga.php'</script>"<?php
}
?>
<body>
<div id="content">
<ul class="menu" id="printhide">
<li><form action="pretraga.php"><input type="submit" value="Pretraga">&nbsp</form></a></li>
</ul>
<br>
<?php
// define variables and set to empty values
$username = $password = "";
$usernameErr = $passwordErr = "";
$error = 0;
//data validation

//check for errors
if (isset($_POST['submit'])) 
{
if (empty($_POST["username"])){
	$usernameErr = "Unesite korisničko ime";
	$error=1;}
else{
	$username = test_input($_POST["username"]);
}
$sql = "SELECT username FROM login WHERE username = '$username'";
	$result = mysqli_query($connection, $sql);
	$result = $connection->query($sql);
	$row = $result->fetch_assoc();
	
if ($result && mysqli_num_rows($result) > 0){
	$usernameErr = "Korisničko ime već postoji";
	$error=1;}
	
if (empty($_POST["password"])){
	$passwordErr = "Unesite lozinku";
	$error=1;}
else{
	$password = test_input($_POST["password"]);
	$password_hash = password_hash($password, PASSWORD_BCRYPT);}

// Insert query
if($error == 0){
	$sql = "INSERT INTO login (username, password) VALUES ('$username', '$password_hash')";
	if(mysqli_query($connection, $sql)){
    echo "Uspešno kreiran korisnik.<br><br>";
	$username = $password = "";}
else{
    echo "Greška pri kreiranju korisnika: " . mysqli_error($connection);
}}
}

//html form
?>

<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
<table>
<tr>
	<td>
		Korisnicko ime: 
	</td>
	<td>
	<input type="text" name="username" value="<?php echo $username;?>">
	</td>
	<td>
	<span style="color:red;"><?php echo $usernameErr;?></span>
	</td>
</tr>
<tr>
		<td>
		Lozinka:
	</td>
	<td>
		<input type="password" name="password" value="<?php echo $password;?>">
	</td>
	<td>
	<span style="color:red;"><?php echo $passwordErr;?></span>
	</td>
</tr>
</table>
<br>
<input type="submit" name="submit" value="Kreiraj korisnika">
</form>
<?php
$sql = "SELECT * FROM login WHERE username <> '$login_session' AND username <> 'admin'";
		$result = $connection->query($sql);
		$rows = 0;
	if ($result->num_rows > 0) {?>
    	<table class='striped tight'>
			<tr><th>Korisnik</th>
				<th>Brisanje</th>
			<?php
			while($row = $result->fetch_assoc()) {
				?>
			<tr><td><?php echo $row['username']?></td>
				<td><a href="brisanjekorisnika.php?id=<?php echo $row['id'] ?>" onClick="return confirm('Da li ste sigurni da želite obrisati korisnika?')"><i class='fa fa-trash' >Brisanje</i></a></td>
			</tr>
			<?php $rows += 1;} 		
			echo "<br>" . $rows . " korisnik(a) prikazan(o)";?>
			<br><br>
			<?php
			}else
			{echo "<br>Nema korisnika osim administratora";}?>
		</table>
</div>
</body>
</html>
	<?php
	mysqli_close($connection);
	?>