<?php 
require_once("includes/db_connection.php");
require_once("includes/functions.php"); ?>
<html lang="en">
	<head>
	<meta charset="utf8">
		<link rel="stylesheet" type="text/css" href="includes/style.css">
		<title>Prijava za volontere - Evropsko Atletsko Prventstvo U Dvorani Beograd 2017</title>
	</head>
	<?php
	//deklaracija promenljivih, pre submit-a
	$ime = $prezime = $roditelj = $datum_rodjenja = $mesto_rodjenja = $jmbg_pasos = $zanimanje = $kompanija = $drzavljanstvo = $email = $fiksni = $mobilni = $maternji_jezik = $engleski = $nemacki = $francuski = $ostalo_jezik = $word = $excel = $internet = $ostalo_racunari = $prethodno_volontiranje = $ostalo_volontiranje = $vreme_volontiranje = $konfekcijski_broj = $ulica = $grad = $postanski_broj = $drzava = $trenutna_adresa = "";
	
	//deklaracija grešaka, default - nema greške
	$imeErr = $prezimeErr = $roditeljErr = $datum_rodjenjaErr = $mesto_rodjenjaErr = $jmbg_pasosErr = $zanimanjeErr = $kompanijaErr = $drzavljanstvoErr = $emailErr = $fiksniErr = $mobilniErr = $maternji_jezikErr = $engleskiErr = $nemackiErr = $francuskiErr = $ostalo_jezikErr = $wordErr = $excelErr = $internetErr = $ostalo_racunariErr = $prethodno_volontiranjeErr = $vreme_volontiranjeErr = $ostalo_volontiranjeErr = $konfekcijski_brojErr = $ulicaErr = $gradErr = $postanski_brojErr = $drzavaErr = $trenutna_adresaErr = "";
	
	//hvatanje promenjivih iz forme i kontrola
	if ($_SERVER["REQUEST_METHOD"] == "POST"){
		$error = 0;
		//ime
		if (empty($_POST["ime"])){
			$imeErr = "Obavezno polje";
			$error = 1;}
		else{
		$ime = test_input($_POST["ime"]);}
		
		//prezime
		if (empty($_POST["prezime"])){
			$prezimeErr = "Obavezno polje";
			$error = 1;}
		else{
		$prezime = test_input($_POST["prezime"]);}
		
		//roditelj
		if (empty($_POST["roditelj"])){
			$roditelj = "";}
		else{
		$roditelj = test_input($_POST["roditelj"]);}
		
		//datum rođenja - Spajanje promenjivih $dan $mesec $godina u $datum_rodjenja, ukoliko je odabrano nešto
		if ((($_POST["dan"]) != "Dan") AND (($_POST["mesec"] != "Mesec")) AND (($_POST["godina"]) != "Godina")){
			$dan = test_input($_POST["dan"]);
			$mesec = test_input($_POST["mesec"]);
			$godina = test_input($_POST["godina"]);
			$datum_rodjenja = $godina . "-" . $mesec . "-" . $dan;}
		else{
			$datum_rodjenjaErr = "Obavezno polje";
			$error = 1;}
			
		
		//mesto rođenja
		if (empty($_POST["mesto_rodjenja"])){
			$mesto_rodjenja = "";}
		else{
		$mesto_rodjenja = test_input($_POST["mesto_rodjenja"]);}			
		
			
		//jmbg_pasos - provera da li su samo brojevi
		if (empty($_POST["jmbg_pasos"])){
			$jmbg_pasos = "";}	
		else {if (!is_numeric($_POST["jmbg_pasos"])){
			$jmbg_pasosErr = "Nepravilan unos";
			$error = 1;}}
		
		if	((!empty($_POST["jmbg_pasos"])) AND (is_numeric($_POST["jmbg_pasos"]))){
		$jmbg_pasos = test_input($_POST["jmbg_pasos"]);
		}
		
		//zanimanje
		if (empty($_POST["zanimanje"])){
			$zanimanje = "";}
		else{
		$zanimanje = test_input($_POST["zanimanje"]);}
		
		//kompanija
		if (empty($_POST["kompanija"])){
			$kompanija = "";}
		else{
		$kompanija = test_input($_POST["kompanija"]);}
		
		//državljanstvo
		if (empty($_POST["drzavljanstvo"])){
			$drzavljanstvoErr = "Obavezno polje";
			$error = 1;}
		else{
		$drzavljanstvo = test_input($_POST["drzavljanstvo"]);}
		
		//ulica i broj
		if (empty($_POST["ulica"])){
			$ulica = "";}
		else{
		$ulica = test_input($_POST["ulica"]);}
		
		//grad
		if (empty($_POST["grad"])){
			$grad = "";}
		else{
		$grad = test_input($_POST["grad"]);}
		
		//poštanski broj - brovera da li su samo brojevi
		if (empty($_POST["postanski_broj"])){
			$postanski_broj = "";}	
		else {if (!is_numeric($_POST["postanski_broj"])){
			$postanski_brojErr = "Nepravilan unos";
			$error = 1;}}
		
		if	((!empty($_POST["postanski_broj"])) AND (is_numeric($_POST["postanski_broj"]))){
		$postanski_broj = test_input($_POST["postanski_broj"]);
		}
		
		//mesto prebivališta
				
		//država
		if (empty($_POST["drzava"])){
			$drzava = "";}
		else{
		$drzava = test_input($_POST["drzava"]);}
		
		//trenutna adresa
		if (empty($_POST["trenutna_adresa"])){
			$trenutna_adresa = "";}
		else{
		$trenutna_adresa = test_input($_POST["trenutna_adresa"]);}

		//e-mail - Proverava pravilan unos e-maila
		if (empty($_POST["email"])){
		$emailErr = "Obavezno polje";
		$error = 1;}
		else{	
		if ((!filter_var(test_input($_POST["email"]), FILTER_VALIDATE_EMAIL))){
		$emailErr = "Nepravilan unos";
		$error = 1;
		}}
		if (((!empty($_POST["email"]))) AND (filter_var(test_input($_POST["email"]), FILTER_VALIDATE_EMAIL))){
		$email = test_input($_POST["email"]);}
		
		//fiksni
		if (empty($_POST["fiksni"])){
			$fiksni = "";}
		else{
		$fiksni = test_input($_POST["fiksni"]);}
		
		//mobilni
		if (empty($_POST["mobilni"])){
			$mobilniErr = "Obavezno polje";
			$error = 1;}
		else{
		$mobilni = test_input($_POST["mobilni"]);}
		
		//maternji jezik
		if (empty($_POST["maternji_jezik"])){
			$maternji_jezik = "";}
		else{
		$maternji_jezik = test_input($_POST["maternji_jezik"]);}
		
		//engleski
		if (empty($_POST["engleski"])){
			$engleskiErr = "Obavezno polje";
			$error = 1;}
		else{
		$engleski = test_input($_POST["engleski"]);}
		

		//francuski
		if (empty($_POST["francuski"])){
			$francuskiErr = "Obavezno polje";
			$error = 1;}
		else{
		$francuski = test_input($_POST["francuski"]);}
		
		//nemacki
		if (empty($_POST["nemacki"])){
			$nemackiErr = "Obavezno polje";
			$error = 1;}
		else{
		$nemacki = test_input($_POST["nemacki"]);}
		
		//ostali jezici
		if (empty($_POST["ostalo_jezik"])){
			$ostalo_jezik = "";}
		else{
		$ostalo_jezik = test_input($_POST["ostalo_jezik"]);}
		
		//word
		if (empty($_POST["word"])){
			$word = "";}
		else{
		$word = test_input($_POST["word"]);}
		
		//excel
		if (empty($_POST["excel"])){
			$excel = "";}
		else{
		$excel = test_input($_POST["excel"]);}
		
		//internet
		if (empty($_POST["internet"])){
			$internet = "";}
		else{
		$internet = test_input($_POST["internet"]);}
		
		//ostalo računari
		if (empty($_POST["ostalo_racunari"])){
			$ostalo_racunari = "";}
		else{
		$ostalo_racunari = test_input($_POST["ostalo_racunari"]);}
		
		//prethodno volontiranje
		if (empty($_POST["prethodno_volontiranje"])){
			$prethodno_volontiranjeErr = "Obavezno polje";
			$error = 1;}
		else{
		$prethodno_volontiranje = test_input($_POST["prethodno_volontiranje"]);}
		
		//ostalo volontiranje
		if ((empty($_POST["ostalo_volontiranje"])) AND ($prethodno_volontiranje == "Da")){
			$ostalo_volontiranjeErr = "Obavezno polje";
			$error = 1;}
		else{
		$ostalo_volontiranje = test_input($_POST["ostalo_volontiranje"]);}
		
		//vreme volontiranje
		if (empty($_POST["vreme_volontiranje"])){
			$vreme_volontiranjeErr = "Obavezno polje";
			$error = 1;}
		else{
		$vreme_volontiranje = test_input($_POST["vreme_volontiranje"]);}
		
		
		//konfekcijski broj
		if (empty($_POST["konfekcijski_broj"])){
			$konfekcijski_brojErr = "Obavezno polje";
			$error = 1;}
		else{
		$konfekcijski_broj = test_input($_POST["konfekcijski_broj"]);}
		
		
		//Upis u bazu podataka ako nema grešaka
		if($error == 0){
			$sql = "INSERT INTO volonteri (ime, prezime, roditelj, datum_rodjenja, mesto_rodjenja, jmbg_pasos, zanimanje, kompanija, drzavljanstvo, ulica_broj, grad, postanski_broj, drzava, adresa, email, fiksni, mobilni, maternji_jezik, engleski, nemacki, francuski, ostalo_jezik, word, excel, internet, ostalo_racunari, prethodno_volontiranje, ostalo_volontiranje, vreme_volontiranje, konfekcijski_broj) VALUES ('$ime', '$prezime', '$roditelj', '$datum_rodjenja', '$mesto_rodjenja', '$jmbg_pasos', '$zanimanje', '$kompanija', '$drzavljanstvo', '$ulica', '$grad', '$postanski_broj', '$drzava', '$trenutna_adresa', '$email', '$fiksni', '$mobilni', '$maternji_jezik', '$engleski', '$nemacki', '$francuski', '$ostalo_jezik', '$word', '$excel', '$internet', '$ostalo_racunari', '$prethodno_volontiranje', '$ostalo_volontiranje', '$vreme_volontiranje', '$konfekcijski_broj')";
			if(mysqli_query($connection, $sql)){
				
				//poruka na vrhu nakon insert-a
				echo "<script type='text/javascript'>alert('Uspešno ste se prijavili!')</script>";
				
				//mail
				$to = $email;
				$subject = "Evropsko Atletsko Prventstvo U Dvorani Beograd 2017 - potvrda prijave za Volontere";
				$txt = "Hvala na interesovanju!<br>Uspešno ste se registrovali za volontiranje na Evropskom atletskom prvenstvu u dvorani Beograd 2017.<br>U narednom periodu ćemo Vas kontaktirati radi zakazivanja intervjua.<br><br>Sportski pozdrav,<br>Evropsko Atletsko Prventstvo U Dvorani Beograd 2017- Sektor Volonteri";
				$headers = 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
				$headers .= "From: volunteers@atletika2017.org.rs";
				mail($to, $subject, $txt, $headers);
				
				//reset polja nakon insert-a
				$ime = $prezime = $roditelj = $datum_rodjenja = $mesto_rodjenja = $jmbg_pasos = $zanimanje = $kompanija = $drzavljanstvo = $email = $fiksni = $mobilni = $maternji_jezik = $engleski = $nemacki = $francuski = $ostalo_jezik = $word = $excel = $internet = $ostalo_racunari = $prethodno_volontiranje = $ostalo_volontiranje = $vreme_volontiranje = $konfekcijski_broj = $ulica = $grad = $postanski_broj = $mesto_prebivalista =$drzava = $trenutna_adresa = "";
				
				
				
			//redirect nakon popunjavanja forme
			?><meta http-equiv="refresh" content="3; url=http://www.belgrade2017.org/" /><?php
			} 
			else{
				echo "<script type='text/javascript'>alert('Došlo je do greške pri upisu u bazu. Pokušajte kasnije.')</script>";				
				}}
		else
			echo "<script type='text/javascript'>alert('Morate popuniti sva obavezna polja!')</script>";
				}
	?>
	
	<body>
<div id="content">
	<img src="files/header.jpg" alt="Evropsko Atletsko Prventstvo U Dvorani Beograd 2017">
	<!--<img src="files/logos.png" alt="Logos">-->
	<br>
	<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
	<div class='heading'><div class='title'>1. Lične informacije</div>
	<div class='subtitle'>Upišite svoje osnovne lične podatke</div></div>
	<table>
	  <tr>
		<td style='width:300'>Ime*:</td>
		<td><input style='width:300' class="field-divided" type="text" name="ime" value="<?php echo $ime;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $imeErr;?></span></td>
	  </tr>
	  <tr>
		<td style='width:300'>Prezime*:</td>
		<td><input style='width:300' type="text" name="prezime" value="<?php echo $prezime;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $prezimeErr;?></span></td>
	  </tr>
	  <tr>
		<td style='width:300'>Ime roditelja:</td>
		<td><input style='width:300' type="text" name="roditelj" value="<?php echo $roditelj;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $roditeljErr;?></span></td>
	  </tr>
	  <tr>
		<td style='width:300'>Datum rođenja*:</td>
		<td>
		<select name="dan">
			<option>Dan</option>
			<option value="01" <?php if (isset($_POST['dan']) && $_POST['dan'] == '01')  echo ' selected="selected"';?>>1</option>
			<option value="02" <?php if (isset($_POST['dan']) && $_POST['dan'] == '02')  echo ' selected="selected"';?>>2</option>
			<option value="03" <?php if (isset($_POST['dan']) && $_POST['dan'] == '03')  echo ' selected="selected"';?>>3</option>
			<option value="04" <?php if (isset($_POST['dan']) && $_POST['dan'] == '04')  echo ' selected="selected"';?>>4</option>
			<option value="05" <?php if (isset($_POST['dan']) && $_POST['dan'] == '05')  echo ' selected="selected"';?>>5</option>
			<option value="06" <?php if (isset($_POST['dan']) && $_POST['dan'] == '06')  echo ' selected="selected"';?>>6</option>
			<option value="07" <?php if (isset($_POST['dan']) && $_POST['dan'] == '07')  echo ' selected="selected"';?>>7</option>
			<option value="08" <?php if (isset($_POST['dan']) && $_POST['dan'] == '08')  echo ' selected="selected"';?>>8</option>
			<option value="09" <?php if (isset($_POST['dan']) && $_POST['dan'] == '09')  echo ' selected="selected"';?>>9</option>
			<option value="10" <?php if (isset($_POST['dan']) && $_POST['dan'] == '10')  echo ' selected="selected"';?>>10</option>
			<option value="11" <?php if (isset($_POST['dan']) && $_POST['dan'] == '11')  echo ' selected="selected"';?>>11</option>
			<option value="12" <?php if (isset($_POST['dan']) && $_POST['dan'] == '12')  echo ' selected="selected"';?>>12</option>
			<option value="13" <?php if (isset($_POST['dan']) && $_POST['dan'] == '13')  echo ' selected="selected"';?>>13</option>
			<option value="14" <?php if (isset($_POST['dan']) && $_POST['dan'] == '14')  echo ' selected="selected"';?>>14</option>
			<option value="15" <?php if (isset($_POST['dan']) && $_POST['dan'] == '15')  echo ' selected="selected"';?>>15</option>
			<option value="16" <?php if (isset($_POST['dan']) && $_POST['dan'] == '16')  echo ' selected="selected"';?>>16</option>
			<option value="17" <?php if (isset($_POST['dan']) && $_POST['dan'] == '17')  echo ' selected="selected"';?>>17</option>
			<option value="18" <?php if (isset($_POST['dan']) && $_POST['dan'] == '18')  echo ' selected="selected"';?>>18</option>
			<option value="19" <?php if (isset($_POST['dan']) && $_POST['dan'] == '19')  echo ' selected="selected"';?>>19</option>
			<option value="20" <?php if (isset($_POST['dan']) && $_POST['dan'] == '20')  echo ' selected="selected"';?>>20</option>
			<option value="21" <?php if (isset($_POST['dan']) && $_POST['dan'] == '21')  echo ' selected="selected"';?>>21</option>
			<option value="22" <?php if (isset($_POST['dan']) && $_POST['dan'] == '22')  echo ' selected="selected"';?>>22</option>
			<option value="23" <?php if (isset($_POST['dan']) && $_POST['dan'] == '23')  echo ' selected="selected"';?>>23</option>
			<option value="24" <?php if (isset($_POST['dan']) && $_POST['dan'] == '24')  echo ' selected="selected"';?>>24</option>
			<option value="25" <?php if (isset($_POST['dan']) && $_POST['dan'] == '25')  echo ' selected="selected"';?>>25</option>
			<option value="26" <?php if (isset($_POST['dan']) && $_POST['dan'] == '26')  echo ' selected="selected"';?>>26</option>
			<option value="27" <?php if (isset($_POST['dan']) && $_POST['dan'] == '27')  echo ' selected="selected"';?>>27</option>
			<option value="28" <?php if (isset($_POST['dan']) && $_POST['dan'] == '28')  echo ' selected="selected"';?>>28</option>
			<option value="29" <?php if (isset($_POST['dan']) && $_POST['dan'] == '29')  echo ' selected="selected"';?>>29</option>
			<option value="30" <?php if (isset($_POST['dan']) && $_POST['dan'] == '30')  echo ' selected="selected"';?>>30</option>
			<option value="31" <?php if (isset($_POST['dan']) && $_POST['dan'] == '31')  echo ' selected="selected"';?>>31</option>
		</select>
		<select name="mesec">
			<option>Mesec</option>
			<option value="01" <?php if (isset($_POST['mesec']) && $_POST['mesec'] == '01')  echo ' selected="selected"';?>>Januar</option>
			<option value="02" <?php if (isset($_POST['mesec']) && $_POST['mesec'] == '02')  echo ' selected="selected"';?>>Februar</option>
			<option value="03" <?php if (isset($_POST['mesec']) && $_POST['mesec'] == '03')  echo ' selected="selected"';?>>Mart</option>
			<option value="04" <?php if (isset($_POST['mesec']) && $_POST['mesec'] == '04')  echo ' selected="selected"';?>>April</option>
			<option value="05" <?php if (isset($_POST['mesec']) && $_POST['mesec'] == '05')  echo ' selected="selected"';?>>Maj</option>
			<option value="06" <?php if (isset($_POST['mesec']) && $_POST['mesec'] == '06')  echo ' selected="selected"';?>>Jun</option>
			<option value="07" <?php if (isset($_POST['mesec']) && $_POST['mesec'] == '07')  echo ' selected="selected"';?>>Jul</option>
			<option value="08" <?php if (isset($_POST['mesec']) && $_POST['mesec'] == '08')  echo ' selected="selected"';?>>Avgust</option>
			<option value="09" <?php if (isset($_POST['mesec']) && $_POST['mesec'] == '09')  echo ' selected="selected"';?>>Septembar</option>
			<option value="10" <?php if (isset($_POST['mesec']) && $_POST['mesec'] == '10')  echo ' selected="selected"';?>>Oktobar</option>
			<option value="11" <?php if (isset($_POST['mesec']) && $_POST['mesec'] == '11')  echo ' selected="selected"';?>>Novembar</option>
			<option value="12" <?php if (isset($_POST['mesec']) && $_POST['mesec'] == '12')  echo ' selected="selected"';?>>Decembar</option>
		</select>
		<select name="godina">
			<option>Godina</option>
			<option value="2016" <?php if (isset($_POST['godina']) && $_POST['godina'] == '2016')  echo ' selected="selected"';?>>2016</option>
			<option value="2015" <?php if (isset($_POST['godina']) && $_POST['godina'] == '2015')  echo ' selected="selected"';?>>2015</option>
			<option value="2014" <?php if (isset($_POST['godina']) && $_POST['godina'] == '2014')  echo ' selected="selected"';?>>2014</option>
			<option value="2013" <?php if (isset($_POST['godina']) && $_POST['godina'] == '2013')  echo ' selected="selected"';?>>2013</option>
			<option value="2012" <?php if (isset($_POST['godina']) && $_POST['godina'] == '2012')  echo ' selected="selected"';?>>2012</option>
			<option value="2011" <?php if (isset($_POST['godina']) && $_POST['godina'] == '2011')  echo ' selected="selected"';?>>2011</option>
			<option value="2010" <?php if (isset($_POST['godina']) && $_POST['godina'] == '2010')  echo ' selected="selected"';?>>2010</option>
			<option value="2009" <?php if (isset($_POST['godina']) && $_POST['godina'] == '2009')  echo ' selected="selected"';?>>2009</option>
			<option value="2008" <?php if (isset($_POST['godina']) && $_POST['godina'] == '2008')  echo ' selected="selected"';?>>2008</option>
			<option value="2007" <?php if (isset($_POST['godina']) && $_POST['godina'] == '2007')  echo ' selected="selected"';?>>2007</option>
			<option value="2006" <?php if (isset($_POST['godina']) && $_POST['godina'] == '2006')  echo ' selected="selected"';?>>2006</option>
			<option value="2005" <?php if (isset($_POST['godina']) && $_POST['godina'] == '2005')  echo ' selected="selected"';?>>2005</option>
			<option value="2004" <?php if (isset($_POST['godina']) && $_POST['godina'] == '2004')  echo ' selected="selected"';?>>2004</option>
			<option value="2003" <?php if (isset($_POST['godina']) && $_POST['godina'] == '2003')  echo ' selected="selected"';?>>2003</option>
			<option value="2002" <?php if (isset($_POST['godina']) && $_POST['godina'] == '2002')  echo ' selected="selected"';?>>2002</option>
			<option value="2001" <?php if (isset($_POST['godina']) && $_POST['godina'] == '2001')  echo ' selected="selected"';?>>2001</option>
			<option value="2000" <?php if (isset($_POST['godina']) && $_POST['godina'] == '2000')  echo ' selected="selected"';?>>2000</option>
			<option value="1999" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1999')  echo ' selected="selected"';?>>1999</option>
			<option value="1998" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1998')  echo ' selected="selected"';?>>1998</option>
			<option value="1997" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1997')  echo ' selected="selected"';?>>1997</option>
			<option value="1996" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1996')  echo ' selected="selected"';?>>1996</option>
			<option value="1995" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1995')  echo ' selected="selected"';?>>1995</option>
			<option value="1994" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1994')  echo ' selected="selected"';?>>1994</option>
			<option value="1993" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1993')  echo ' selected="selected"';?>>1993</option>
			<option value="1992" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1992')  echo ' selected="selected"';?>>1992</option>
			<option value="1991" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1991')  echo ' selected="selected"';?>>1991</option>
			<option value="1990" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1990')  echo ' selected="selected"';?>>1990</option>
			<option value="1989" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1989')  echo ' selected="selected"';?>>1989</option>
			<option value="1988" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1988')  echo ' selected="selected"';?>>1988</option>
			<option value="1987" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1987')  echo ' selected="selected"';?>>1987</option>
			<option value="1986" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1986')  echo ' selected="selected"';?>>1986</option>
			<option value="1985" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1985')  echo ' selected="selected"';?>>1985</option>
			<option value="1984" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1984')  echo ' selected="selected"';?>>1984</option>
			<option value="1983" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1983')  echo ' selected="selected"';?>>1983</option>
			<option value="1982" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1982')  echo ' selected="selected"';?>>1982</option>
			<option value="1981" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1981')  echo ' selected="selected"';?>>1981</option>
			<option value="1980" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1980')  echo ' selected="selected"';?>>1980</option>
			<option value="1979" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1979')  echo ' selected="selected"';?>>1979</option>
			<option value="1978" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1978')  echo ' selected="selected"';?>>1978</option>
			<option value="1977" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1977')  echo ' selected="selected"';?>>1977</option>
			<option value="1976" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1976')  echo ' selected="selected"';?>>1976</option>
			<option value="1975" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1975')  echo ' selected="selected"';?>>1975</option>
			<option value="1974" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1974')  echo ' selected="selected"';?>>1974</option>
			<option value="1973" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1973')  echo ' selected="selected"';?>>1973</option>
			<option value="1972" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1972')  echo ' selected="selected"';?>>1972</option>
			<option value="1971" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1971')  echo ' selected="selected"';?>>1971</option>
			<option value="1970" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1970')  echo ' selected="selected"';?>>1970</option>
			<option value="1969" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1969')  echo ' selected="selected"';?>>1969</option>
			<option value="1968" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1968')  echo ' selected="selected"';?>>1968</option>
			<option value="1967" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1967')  echo ' selected="selected"';?>>1967</option>
			<option value="1966" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1966')  echo ' selected="selected"';?>>1966</option>
			<option value="1965" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1965')  echo ' selected="selected"';?>>1965</option>
			<option value="1964" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1964')  echo ' selected="selected"';?>>1964</option>
			<option value="1963" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1963')  echo ' selected="selected"';?>>1963</option>
			<option value="1962" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1962')  echo ' selected="selected"';?>>1962</option>
			<option value="1961" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1961')  echo ' selected="selected"';?>>1961</option>
			<option value="1960" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1960')  echo ' selected="selected"';?>>1960</option>
			<option value="1959" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1959')  echo ' selected="selected"';?>>1959</option>
			<option value="1958" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1958')  echo ' selected="selected"';?>>1958</option>
			<option value="1957" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1957')  echo ' selected="selected"';?>>1957</option>
			<option value="1956" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1956')  echo ' selected="selected"';?>>1956</option>
			<option value="1955" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1955')  echo ' selected="selected"';?>>1955</option>
			<option value="1954" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1954')  echo ' selected="selected"';?>>1954</option>
			<option value="1953" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1953')  echo ' selected="selected"';?>>1953</option>
			<option value="1952" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1952')  echo ' selected="selected"';?>>1952</option>
			<option value="1951" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1951')  echo ' selected="selected"';?>>1951</option>
			<option value="1950" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1950')  echo ' selected="selected"';?>>1950</option>
			<option value="1949" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1949')  echo ' selected="selected"';?>>1949</option>
			<option value="1948" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1948')  echo ' selected="selected"';?>>1948</option>
			<option value="1947" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1947')  echo ' selected="selected"';?>>1947</option>
			<option value="1946" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1946')  echo ' selected="selected"';?>>1946</option>
			<option value="1945" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1945')  echo ' selected="selected"';?>>1945</option>
			<option value="1944" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1944')  echo ' selected="selected"';?>>1944</option>
			<option value="1943" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1943')  echo ' selected="selected"';?>>1943</option>
			<option value="1942" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1942')  echo ' selected="selected"';?>>1942</option>
			<option value="1941" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1941')  echo ' selected="selected"';?>>1941</option>
			<option value="1940" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1940')  echo ' selected="selected"';?>>1940</option>
			<option value="1939" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1939')  echo ' selected="selected"';?>>1939</option>
			<option value="1938" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1938')  echo ' selected="selected"';?>>1938</option>
			<option value="1937" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1937')  echo ' selected="selected"';?>>1937</option>
			<option value="1936" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1936')  echo ' selected="selected"';?>>1936</option>
			<option value="1935" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1935')  echo ' selected="selected"';?>>1935</option>
			<option value="1934" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1934')  echo ' selected="selected"';?>>1934</option>
			<option value="1933" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1933')  echo ' selected="selected"';?>>1933</option>
			<option value="1932" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1932')  echo ' selected="selected"';?>>1932</option>
			<option value="1931" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1931')  echo ' selected="selected"';?>>1931</option>
			<option value="1930" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1930')  echo ' selected="selected"';?>>1930</option>
			<option value="1929" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1929')  echo ' selected="selected"';?>>1929</option>
			<option value="1928" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1928')  echo ' selected="selected"';?>>1928</option>
			<option value="1927" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1927')  echo ' selected="selected"';?>>1927</option>
			<option value="1926" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1926')  echo ' selected="selected"';?>>1926</option>
			<option value="1925" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1925')  echo ' selected="selected"';?>>1925</option>
			<option value="1924" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1924')  echo ' selected="selected"';?>>1924</option>
			<option value="1923" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1923')  echo ' selected="selected"';?>>1923</option>
			<option value="1922" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1922')  echo ' selected="selected"';?>>1922</option>
			<option value="1921" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1921')  echo ' selected="selected"';?>>1921</option>
			<option value="1920" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1920')  echo ' selected="selected"';?>>1920</option>
			<option value="1919" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1919')  echo ' selected="selected"';?>>1919</option>
			<option value="1918" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1918')  echo ' selected="selected"';?>>1918</option>
			<option value="1917" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1917')  echo ' selected="selected"';?>>1917</option>
			<option value="1916" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1916')  echo ' selected="selected"';?>>1916</option>
			<option value="1915" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1915')  echo ' selected="selected"';?>>1915</option>
			<option value="1914" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1914')  echo ' selected="selected"';?>>1914</option>
			<option value="1913" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1913')  echo ' selected="selected"';?>>1913</option>
			<option value="1912" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1912')  echo ' selected="selected"';?>>1912</option>
			<option value="1911" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1911')  echo ' selected="selected"';?>>1911</option>
			<option value="1910" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1910')  echo ' selected="selected"';?>>1910</option>
			<option value="1909" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1909')  echo ' selected="selected"';?>>1909</option>
			<option value="1908" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1908')  echo ' selected="selected"';?>>1908</option>
			<option value="1907" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1907')  echo ' selected="selected"';?>>1907</option>
			<option value="1906" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1906')  echo ' selected="selected"';?>>1906</option>
			<option value="1905" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1905')  echo ' selected="selected"';?>>1905</option>
			<option value="1904" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1904')  echo ' selected="selected"';?>>1904</option>
			<option value="1903" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1903')  echo ' selected="selected"';?>>1903</option>
			<option value="1902" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1902')  echo ' selected="selected"';?>>1902</option>
			<option value="1901" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1901')  echo ' selected="selected"';?>>1901</option>
			<option value="1900" <?php if (isset($_POST['godina']) && $_POST['godina'] == '1900')  echo ' selected="selected"';?>>1900</option>
		</select>
</td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $datum_rodjenjaErr;?></span></td>
	  </tr>
	  <tr>
	    <td style='width:300'>Mesto rođenja:</td>
		<td><input style='width:300' type="text" name="mesto_rodjenja" value="<?php echo $mesto_rodjenja;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $mesto_rodjenjaErr;?></span></td>
	  </tr>
	  <tr>
	    <td style='width:300'>JMBG/Pasoš:</td>
		<td><input style='width:300' type="text" name="jmbg_pasos" value="<?php echo $jmbg_pasos;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $jmbg_pasosErr;?></span></td>
	  </tr>
	  <tr>
		<td style='width:300'>Zanimanje:</td>
		<td><input style='width:300' type="text" name="zanimanje" value="<?php echo $zanimanje;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $zanimanjeErr;?></span></td>
	  </tr>
	  <tr>
		<td style='width:300'>Ime kompanije/fakulteta/škole:</td>
		<td><input style='width:300' type="text" name="kompanija" value="<?php echo $kompanija;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $kompanijaErr;?></span></td>
	  </tr>
	</table>
	<div class='heading'><div class='title'>2. Državljanstvo Republike Srbije*</div></div>
	<table>
	<tr>
		<td>
			<input type="radio" name="drzavljanstvo" value="Da" <?php if (isset($_POST['drzavljanstvo']) && $_POST['drzavljanstvo'] == 'Da')  echo ' checked="checked"';?>>Da<br>
			<input type="radio" name="drzavljanstvo" value="Ne" <?php if (isset($_POST['drzavljanstvo']) && $_POST['drzavljanstvo'] == 'Ne')  echo ' checked="checked"';?>>Ne
		</td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $drzavljanstvoErr;?></span></td>
	 </tr>
	</table>
	<div class='heading'><div class='title'>3. Adresa</div>
	<div class='subtitle'>Upišite svoju adresu (iz lične karte, indeksa, đačke knjižice...)</div></div>
	<table>
	  <tr>
		<td style='width:300'>Ulica i broj:</td>
		<td><input style='width:300' type="text" name="ulica" value="<?php echo $ulica;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $ulicaErr;?></span></td>
	  </tr>
	   <tr>
		<td style='width:300'>Grad:</td>
		<td><input style='width:300' type="text" name="grad" value="<?php echo $grad;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $gradErr;?></span></td>
	  </tr>
	  <tr>
		<td style='width:300'>Poštanski broj:</td>
		<td><input style='width:300' type="text" name="postanski_broj" value="<?php echo $postanski_broj;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $postanski_brojErr;?></span></td>
	  </tr>
	  <tr>
		<td style='width:300'>Država:</td>
		<td><input style='width:300' type="text" name="drzava" value="<?php echo $drzava;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $drzavaErr;?></span></td>
	  </tr>
	  <tr>
		<td style='width:300'>Trenutna adresa:</td>
		<td><input style='width:300' type="text" name="trenutna_adresa" value="<?php echo $trenutna_adresa;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $trenutna_adresaErr;?></span></td>
	  </tr>
	</table>
	<div class='heading'><div class='title'>4. Kontakt informacije</div>
	<div class='subtitle'>Molimo Vas da upišete kontakt telefon i e-mail adresu. Ova e-mail adresa će se koristiti za komunikaciju sa vama</div></div>
	<table>
	<tr>
		<td style='width:300'>E-mail*:</td>
		<td><input style='width:300' type="text" name="email" value="<?php echo $email;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $emailErr;?></span></td>
	</tr>
	<tr>
		<td style='width:300'>Fiksni telefon:</td>
		<td><input style='width:300' type="text" name="fiksni" value="<?php echo $fiksni;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $fiksniErr;?></span></td>
	</tr>	
	<tr>
		<td style='width:300'>Mobilni telefon*:</td>
		<td><input style='width:300' type="text" name="mobilni" value="<?php echo $mobilni;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $mobilniErr;?></span></td>
	</tr>	
	<tr>
		<td style='width:300'>Jezik komunikacije (maternji):</td>
		<td><input style='width:300' type="text" name="maternji_jezik" value="<?php echo $maternji_jezik;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $maternji_jezikErr;?></span></td>
	</tr>	
	</table>
	<div class='heading'><div class='title'>5. Tvoje veštine</div></div>
	<br>
	<div class='heading_small'><div class='subtitle'>Znanje jezika</div></div>
	<table>
	<tr>
		<td style='width:300'>Engleski:</td>
		<td><select name="engleski">
			<option value="Nema znanje" <?php if (isset($_POST['engleski']) && $_POST['engleski'] == 'Nema znanje')  echo ' selected="selected"';?>>Nema znanje</option>
			<option value="Elementarno" <?php if (isset($_POST['engleski']) && $_POST['engleski'] == 'Elementarno')  echo ' selected="selected"';?>>Elementarno</option>
			<option value="Nizi srednji" <?php if (isset($_POST['engleski']) && $_POST['engleski'] == 'Nizi srednji')  echo ' selected="selected"';?>>Niži srednji</option>
			<option value="Visi srednji" <?php if (isset($_POST['engleski']) && $_POST['engleski'] == 'Visi srednji')  echo ' selected="selected"';?>>Viši srednji</option>
			<option value="Nizi napredni" <?php if (isset($_POST['engleski']) && $_POST['engleski'] == 'Nizi napredni')  echo ' selected="selected"';?>>Niži napredni</option>
			<option value="Visi napredni" <?php if (isset($_POST['engleski']) && $_POST['engleski'] == 'Visi napredni')  echo ' selected="selected"';?>>Viši napredni</option>
		</select>
		</td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $engleskiErr;?></span></td>
	</tr>
	<tr>
		<td style='width:300'>Francuski:</td>
		<td><select name="francuski">
			<option value="Nema znanje" <?php if (isset($_POST['francuski']) && $_POST['francuski'] == 'Nema znanje')  echo ' selected="selected"';?>>Nema znanje</option>
			<option value="Elementarno" <?php if (isset($_POST['francuski']) && $_POST['francuski'] == 'Elementarno')  echo ' selected="selected"';?>>Elementarno</option>
			<option value="Nizi srednji" <?php if (isset($_POST['francuski']) && $_POST['francuski'] == 'Nizi srednji')  echo ' selected="selected"';?>>Niži srednji</option>
			<option value="Visi srednji" <?php if (isset($_POST['francuski']) && $_POST['francuski'] == 'Visi srednji')  echo ' selected="selected"';?>>Viši srednji</option>
			<option value="Nizi napredni" <?php if (isset($_POST['francuski']) && $_POST['francuski'] == 'Nizi napredni')  echo ' selected="selected"';?>>Niži napredni</option>
			<option value="Visi napredni" <?php if (isset($_POST['francuski']) && $_POST['francuski'] == 'Visi napredni')  echo ' selected="selected"';?>>Viši napredni</option>
		</select>
		</td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $francuskiErr;?></span></td>
	</tr>
	<tr>
		<td style='width:300'>Nemački:</td>
		<td><select name="nemacki">
			<option value="Nema znanje" <?php if (isset($_POST['nemacki']) && $_POST['nemacki'] == 'Nema znanje')  echo ' selected="selected"';?>>Nema znanje</option>
			<option value="Elementarno" <?php if (isset($_POST['nemacki']) && $_POST['nemacki'] == 'Elementarno')  echo ' selected="selected"';?>>Elementarno</option>
			<option value="Nizi srednji" <?php if (isset($_POST['nemacki']) && $_POST['nemacki'] == 'Nizi srednji')  echo ' selected="selected"';?>>Niži srednji</option>
			<option value="Visi srednji" <?php if (isset($_POST['nemacki']) && $_POST['nemacki'] == 'Visi srednji')  echo ' selected="selected"';?>>Viši srednji</option>
			<option value="Nizi napredni" <?php if (isset($_POST['nemacki']) && $_POST['nemacki'] == 'Nizi napredni')  echo ' selected="selected"';?>>Niži napredni</option>
			<option value="Visi napredni" <?php if (isset($_POST['nemacki']) && $_POST['nemacki'] == 'Visi napredni')  echo ' selected="selected"';?>>Viši napredni</option>
		</select>
		</td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $nemackiErr;?></span></td>
	</tr>
	<tr>
		<td style='width:300'>Ostali jezici:</td>
		<td><input style='width:300' type="text" name="ostalo_jezik" value="<?php echo $ostalo_jezik;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $ostalo_jezikErr;?></span></td>
	</tr>
	</table>
	<div class='heading_small'><div class ='subtitle'>Poznavanje rada na računaru</div></div>
	<table>
	<tr>
		<td style='width:300'>Word:</td>
		<td><select name="word">
			<option value="Slabo" <?php if (isset($_POST['word']) && $_POST['word'] == 'Slabo')  echo ' selected="selected"';?>>Slabo</option>
			<option value="Osnovno" <?php if (isset($_POST['word']) && $_POST['word'] == 'Osnovno')  echo ' selected="selected"';?>>Osnovno</option>
			<option value="Srednje" <?php if (isset($_POST['word']) && $_POST['word'] == 'Srednje')  echo ' selected="selected"';?>>Srednje</option>
			<option value="Napredno" <?php if (isset($_POST['word']) && $_POST['word'] == 'Napredno')  echo ' selected="selected"';?>>Napredno</option>
		</select>
		</td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $wordErr;?></span></td>
	</tr>
	<tr>
		<td style='width:300'>Excel:</td>
		<td><select name="excel">
			<option value="Slabo" <?php if (isset($_POST['excel']) && $_POST['excel'] == 'Slabo')  echo ' selected="selected"';?>>Slabo</option>
			<option value="Osnovno" <?php if (isset($_POST['excel']) && $_POST['excel'] == 'Osnovno')  echo ' selected="selected"';?>>Osnovno</option>
			<option value="Srednje" <?php if (isset($_POST['excel']) && $_POST['excel'] == 'Srednje')  echo ' selected="selected"';?>>Srednje</option>
			<option value="Napredno" <?php if (isset($_POST['excel']) && $_POST['excel'] == 'Napredno')  echo ' selected="selected"';?>>Napredno</option>
		</select>
		</td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $excelErr;?></span></td>
	</tr>	
	<tr>
		<td style='width:300'>Internet:</td>
		<td><select name="internet">
			<option value="Slabo" <?php if (isset($_POST['internet']) && $_POST['internet'] == 'Slabo')  echo ' selected="selected"';?>>Slabo</option>
			<option value="Osnovno" <?php if (isset($_POST['internet']) && $_POST['internet'] == 'Osnovno')  echo ' selected="selected"';?>>Osnovno</option>
			<option value="Srednje" <?php if (isset($_POST['internet']) && $_POST['internet'] == 'Srednje')  echo ' selected="selected"';?>>Srednje</option>
			<option value="Napredno" <?php if (isset($_POST['internet']) && $_POST['internet'] == 'Napredno')  echo ' selected="selected"';?>>Napredno</option>
		</select>
		</td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $internetErr;?></span></td>
	</tr>	
	<tr>
		<td style='width:300'>Ostali programi:</td>
		<td><input style='width:300' type="text" name="ostalo_racunari" value="<?php echo $ostalo_racunari;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $ostalo_racunariErr;?></span></td>
	</tr>	
	</table>
	<div class='heading'><div class='title'>6. O volontiranju</h2></div></div>
	<table>
	<tr>
		<td style='width:200'>Prethodno volontiranje*:</td>
		<td>
			<input type="radio" name="prethodno_volontiranje" value="Da" <?php if (isset($_POST['prethodno_volontiranje']) && $_POST['prethodno_volontiranje'] == 'Da')  echo ' checked="checked"';?>>Da <input type="radio" name="prethodno_volontiranje" value="Ne" <?php if (isset($_POST['prethodno_volontiranje']) && $_POST['prethodno_volontiranje'] == 'Ne')  echo ' checked="checked"';?>>Ne
		</td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $prethodno_volontiranjeErr;?></span></td>
	</tr>
	<tr>
		<td style='width:200'>Moje volontersko iskustvo:</td>
		<td><input style='width:300' type="text" name="ostalo_volontiranje" value="<?php echo $ostalo_volontiranje;?>"></td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $ostalo_volontiranjeErr;?></span></td>
	</tr>	
	<tr>
		<td style='width:200'>Volontiraću*:</td>
		<td><br>
			<input type="radio" name="vreme_volontiranje" value="Tokom citavog projekta" <?php if (isset($_POST['vreme_volontiranje']) && $_POST['vreme_volontiranje'] == 'Tokom citavog projekta')  echo ' checked="checked"';?>>Tokom čitavog projekta uključujući i promotivne aktivnosti<br> 
			<input type="radio" name="vreme_volontiranje" value="Samo za vreme prventstva" <?php if (isset($_POST['vreme_volontiranje']) && $_POST['vreme_volontiranje'] == 'Samo za vreme prventstva')  echo ' checked="checked"';?>>Samo za vreme Evropskog atletskog prvenstva u dvorani 01. - 06.03.2017.
		</td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $vreme_volontiranjeErr;?></span></td>
	</tr>
	<tr>
		<td style='width:200'><br>Konfekcijski broj*:</td>
		<td><br>
			<input type="radio" name="konfekcijski_broj" value="XS" <?php if (isset($_POST['konfekcijski_broj']) && $_POST['konfekcijski_broj'] == 'XS')  echo ' checked="checked"';?>>XS
			<input type="radio" name="konfekcijski_broj" value="S" <?php if (isset($_POST['konfekcijski_broj']) && $_POST['konfekcijski_broj'] == 'S')  echo ' checked="checked"';?>>S
			<input type="radio" name="konfekcijski_broj" value="M" <?php if (isset($_POST['konfekcijski_broj']) && $_POST['konfekcijski_broj'] == 'M')  echo ' checked="checked"';?>>M
			<input type="radio" name="konfekcijski_broj" value="L" <?php if (isset($_POST['konfekcijski_broj']) && $_POST['konfekcijski_broj'] == 'L')  echo ' checked="checked"';?>>L
			<input type="radio" name="konfekcijski_broj" value="XL" <?php if (isset($_POST['konfekcijski_broj']) && $_POST['konfekcijski_broj'] == 'XL')  echo ' checked="checked"';?>>XL
			<input type="radio" name="konfekcijski_broj" value="XXL" <?php if (isset($_POST['konfekcijski_broj']) && $_POST['konfekcijski_broj'] == 'XXL')  echo ' checked="checked"';?>>XXL
			<input type="radio" name="konfekcijski_broj" value="XXXL" <?php if (isset($_POST['konfekcijski_broj']) && $_POST['konfekcijski_broj'] == 'XXXL')  echo ' checked="checked"';?>>XXXL
		</td>
		<td><span style="background-color: #D33943;color: white;"><?php echo $konfekcijski_brojErr;?></span></td>
	</tr>
	</table>
	<br>
	<div class='center'><input style='width:300; height:60; background-color: #F95817; border: 1px solid #000; border-color: #aaa #444 #444 #aaa; color: white;' type="submit" name="submit" value="Prijavi se"></div>
	</form>
</div>
	<?php
	mysqli_close($connection);?>
</body>
</html>

