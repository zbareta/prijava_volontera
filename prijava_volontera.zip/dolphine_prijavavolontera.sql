-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 21, 2017 at 08:30 AM
-- Server version: 5.5.55-cll
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dolphine_prijavavolontera`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(64) NOT NULL,
  `password` varchar(1024) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `created`) VALUES
(10, 'zbareta', '$2y$10$VCdNQbEGtUVrMR475iu2B./hkCWBTrToEr2rXetPvf./qB0hgWWgm', '2015-12-06 10:33:19'),
(11, 'slavetoaudio', '$2y$10$yx.GRr57BzUUo50Wy6c2UuhHlpYZ81oT6OnmSlrag89fLN1O3UCiC', '2015-12-06 10:50:35'),
(13, 'admin', '$2y$10$xwhK1exdkx2xIMG0RFapc./hNtdmcCgtMP.RG51T7rS1Z04KXScA2', '2016-05-23 18:58:44');

-- --------------------------------------------------------

--
-- Table structure for table `pozivi`
--

CREATE TABLE `pozivi` (
  `id` int(11) NOT NULL,
  `javio_se` varchar(64) NOT NULL,
  `komentar` varchar(1024) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `volonteri_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pozivi`
--

INSERT INTO `pozivi` (`id`, `javio_se`, `komentar`, `created`, `volonteri_id`) VALUES
(23, 'Ne', 'nije se javio', '2016-02-25 07:13:32', 96),
(22, 'Da', 'brzo se javio', '2016-02-25 07:13:28', 96);

-- --------------------------------------------------------

--
-- Table structure for table `sektori`
--

CREATE TABLE `sektori` (
  `id` int(11) NOT NULL,
  `naziv` varchar(256) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sektori`
--

INSERT INTO `sektori` (`id`, `naziv`, `created`) VALUES
(6, 'Finansije', '2015-11-29 08:29:24'),
(5, 'IT sektor', '2015-11-29 08:28:34'),
(7, 'Obezbedjenje', '2015-11-29 08:29:39'),
(8, '', '2015-11-29 09:00:14');

-- --------------------------------------------------------

--
-- Table structure for table `treninzi`
--

CREATE TABLE `treninzi` (
  `id` int(11) NOT NULL,
  `komentar` varchar(1024) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `volonteri_id` int(11) NOT NULL,
  `datum` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `volonteri`
--

CREATE TABLE `volonteri` (
  `id` int(11) NOT NULL,
  `ime` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `prezime` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `roditelj` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `datum_rodjenja` date NOT NULL,
  `mesto_rodjenja` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `jmbg_pasos` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `zanimanje` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `kompanija` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `drzavljanstvo` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `ulica_broj` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `grad` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `postanski_broj` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `drzava` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `adresa` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `fiksni` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `mobilni` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `maternji_jezik` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `engleski` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `francuski` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `nemacki` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `ostalo_jezik` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `word` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `excel` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `internet` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `ostalo_racunari` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `prethodno_volontiranje` varchar(3000) COLLATE utf8_unicode_ci NOT NULL,
  `ostalo_volontiranje` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `vreme_volontiranje` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `konfekcijski_broj` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ocena` int(11) NOT NULL,
  `sektor` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `zapazanja` varchar(1024) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pozivi`
--
ALTER TABLE `pozivi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sektori`
--
ALTER TABLE `sektori`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `treninzi`
--
ALTER TABLE `treninzi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `volonteri`
--
ALTER TABLE `volonteri`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `pozivi`
--
ALTER TABLE `pozivi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `sektori`
--
ALTER TABLE `sektori`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `treninzi`
--
ALTER TABLE `treninzi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `volonteri`
--
ALTER TABLE `volonteri`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=745;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
